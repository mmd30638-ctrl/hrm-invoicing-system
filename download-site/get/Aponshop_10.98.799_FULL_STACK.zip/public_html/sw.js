// Aponshop offline service worker — visited pages + POS + payments
const cacheName = 'ame-pwa-v1098799';
const staticAssets = [
  './offline.html',
  './offline-fix.html',
  './offline-sale.html',
  './offline-payment.html',
  './offline-customers.html',
  './offline-products.html',
  './offline-product-add.html',
  './offline-purchase.html',
  './offline-expense.html',
  './offline-workshop.html',
  './offline-supplier-pay.html',
  './offline-transfer.html',
  './offline-pulse.html',
  './offline-module.html',
  './assets/css/theme.css',
  './assets/css/device-fit.css',
  './assets/css/fulldisplay-fix.css',
  './assets/css/premium-saas.css',
  './assets/css/pos-skins.css',
  './assets/css/pos-box-type.css',
  './assets/css/hdr-icons.css',
  './assets/css/ticker-voice.827.css',
  './assets/css/home-banner.css',
  './assets/css/inventory-first-home.710.css',
  './assets/css/pulse.css',
  './assets/css/workshop.css',
  './assets/css/agents.css',
  './assets/css/smart.css',
  './assets/css/responsive-fix.css',
  './assets/css/display-widgets.css',
  './assets/css/customer-payment.css',
  './assets/css/offline-app.css',
  './assets/css/offline-pos-clone.css',
  './assets/css/submit-spinner.css',
  './assets/css/transfer-desk.css',
  './assets/css/app-shell.css',
  './assets/img/ma-logo.png',
  './assets/img/header-logo.png',
  './assets/img/icon-192.png',
  './assets/img/icon-512.png',
  './assets/img/icon-maskable-512.png',
  './assets/img/apple-touch-icon.png',
  './assets/js/app-install.js',
  './assets/js/display-widgets.js',
  './assets/js/offline-queue.js',
  './assets/js/offline-payment-queue.js',
  './assets/js/offline-pay-nav.js',
  './assets/js/offline-boot.js',
  './assets/js/offline-atlas.js',
  './assets/js/offline-hub.js',
  './assets/js/offline-pos-desk.js',
  './assets/js/pos-cart.js',
  './assets/js/pos-payment.js',
  './assets/js/ame-sale-desk.js',
  './assets/js/double-submit-guard.js',
  './assets/js/edge-pulse.js',
  './assets/js/premium-saas.710.js',
  './assets/js/inventory-first-home.710.js',
  './assets/js/responsive-fix.js',
  './manifest.json'
];

function pathOf(url) {
  try {
    return new URL(url, self.location.origin).pathname || '';
  } catch (e) {
    return '';
  }
}

function isPaymentUrl(url) {
  const path = url.pathname || '';
  return path.indexOf('payment-receive.php') !== -1
    || path.indexOf('offline-payment.html') !== -1;
}

function isPosUrl(url) {
  const path = url.pathname || '';
  return path.indexOf('/modules/sales/pos.php') !== -1
    || path.indexOf('/offline-sale.html') !== -1
    || path.indexOf('/assets/js/pos-') !== -1
    || path.indexOf('/assets/css/pos-') !== -1;
}

function isHireListPath(path) {
  return path.indexOf('/modules/customers/hire/') !== -1
    || path.indexOf('/chuktis.php') !== -1
    || path.indexOf('/now.php') !== -1;
}

function isDownloadPath(path) {
  return path === '/download.php'
    || path === '/download_update.php'
    || path.indexOf('/downloads/') === 0
    || /\.zip$/i.test(path);
}

function isAuthPath(path) {
  return path === '/login.php'
    || path === '/logout.php'
    || path.indexOf('forgot_password') !== -1
    || path.indexOf('reset_password') !== -1
    || path.indexOf('process_login') !== -1
    || path.indexOf('process_forgot') !== -1
    || path.indexOf('process_password') !== -1
    || path.indexOf('process_new_password') !== -1;
}

function isWritePath(path) {
  return path.indexOf('process_sale.php') !== -1
    || path.indexOf('process_payment.php') !== -1
    || path.indexOf('process_purchase.php') !== -1
    || path.indexOf('process_product.php') !== -1
    || path.indexOf('process_pay.php') !== -1
    || path.indexOf('process_transfer.php') !== -1
    || path.indexOf('job_process.php') !== -1
    || path.indexOf('factory_reset') !== -1
    || path.indexOf('backup_download') !== -1
    || path.indexOf('/actions/process') !== -1;
}

function shouldCache(url, res) {
  const path = url.pathname || '';
  const cacheControl = (res && res.headers.get('Cache-Control')) || '';
  // PHP responses can contain authenticated business data. Keep only static
  // offline shells and assets in Cache Storage.
  if (path.endsWith('.php') || path.endsWith('/')) return false;
  if (/\b(no-store|private)\b/i.test(cacheControl)) return false;
  if (isAuthPath(path) || isWritePath(path)) return false;
  try {
    const finalPath = new URL(res.url).pathname;
    if (finalPath.endsWith('.php') || finalPath.endsWith('/')) return false;
    if (isAuthPath(finalPath) || isWritePath(finalPath)) return false;
  } catch (e) {}
  if (!assetBodyOk(path, res)) return false;
  return !!(res && res.ok);
}

function assetBodyOk(path, res) {
  const ct = String((res && res.headers && res.headers.get('content-type')) || '').toLowerCase();
  if (!ct) return true;
  const isHtmlPath = path.endsWith('.html');
  if (isHtmlPath) {
    return ct.indexOf('text/html') !== -1 || ct.indexOf('text/plain') !== -1;
  }
  if (ct.indexOf('text/html') !== -1) return false;
  if (path.endsWith('.css')) return ct.indexOf('text/css') !== -1;
  if (path.endsWith('.js')) return ct.indexOf('javascript') !== -1 || ct.indexOf('ecmascript') !== -1;
  return true;
}

function isHomePath(path) {
  return path === '/' || path === '/index.php' || path === '/m' || path === '/m/'
    || path === '/offline.html' || path === '/index.html';
}

function injectIfBoot(req, res) {
  try {
    const ct = String(res.headers.get('content-type') || '').toLowerCase();
    const path = new URL(req.url).pathname || '';
    if (isDownloadPath(path)) return Promise.resolve(res);
    if (ct && ct.indexOf('text/html') === -1) return Promise.resolve(res);
    const wantsHtml = req.mode === 'navigate' || ct.indexOf('text/html') !== -1;
    if (!wantsHtml || !res.ok) return Promise.resolve(res);
    if (path.indexOf('/assets/') === 0) return Promise.resolve(res);
    return res.text().then(function (html) {
      if (html.indexOf('inventory-first-home.710.js') !== -1) {
        return new Response(html, { status: res.status, statusText: res.statusText, headers: res.headers });
      }
      const snip = '\n<link rel="stylesheet" href="/assets/css/inventory-first-home.710.css">\n<script src="/assets/js/inventory-first-home.710.js" defer></script>\n';
      const out = /<\/head>/i.test(html) ? html.replace(/<\/head>/i, snip + '</head>') : html;
      const headers = new Headers(res.headers);
      headers.delete('content-length');
      return new Response(out, { status: res.status, statusText: res.statusText, headers: headers });
    });
  } catch (e) {
    return Promise.resolve(res);
  }
}

function hubHtml() {
  return "<!DOCTYPE html>\n<html lang=\"bn\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>অফলাইন দোকান</title>\n<style>\n/* Offline shop — same desk colors as the live POS. */\n:root{\n  --desk-navy:#003F8F;\n  --desk-blue:#0057B8;\n  --desk-green:#04933A;\n  --desk-canvas:#F4F7FB;\n  --desk-line:#D7DEE8;\n  --desk-text:#111827;\n  --desk-muted:#667085;\n  --desk-surface:#F8FAFC;\n  --desk-white:#ffffff;\n}\nhtml,body{font-family:\"Noto Sans Bengali\",\"Segoe UI\",sans-serif;background:#F4F7FB;margin:0;color:#111827}\nbody{padding:12px 12px 24px}\n.wrap{max-width:640px;margin:0 auto}\n.card,.desk-card{background:#ffffff;border:1px solid #D7DEE8;border-radius:12px;padding:0 12px 12px;margin-bottom:12px;box-shadow:0 8px 20px rgba(15,23,42,.05);overflow:hidden}\n.desk-card>h1,.desk-card>h2,.desk-head,.ame-desk-bar{\n  display:flex;align-items:center;justify-content:space-between;gap:8px;\n  margin:0 -12px 12px;padding:10px 12px;background:#003F8F;color:#ffffff;\n  font-size:15px;font-weight:800;border-radius:12px 12px 0 0\n}\nh1{margin:0 0 8px;font-size:20px;color:#111827}\np{color:#667085;line-height:1.5}\ninput,select,textarea{width:100%;padding:11px 12px;border:1px solid #D7DEE8;border-radius:8px;box-sizing:border-box;margin-top:6px;background:#ffffff;color:#111827;min-height:40px}\nlabel{font-size:12px;font-weight:800;display:block;margin-top:10px;color:#111827}\n.hit{padding:10px 0;border-bottom:1px solid #D7DEE8;cursor:pointer;color:#111827}\ntable{width:100%;border-collapse:collapse;font-size:13px}\nth{background:#003F8F;color:#ffffff;padding:8px 6px;text-align:center;font-weight:800}\ntd{padding:8px 6px;border-bottom:1px solid #D7DEE8;text-align:center;background:#ffffff;color:#111827}\n.btn{width:100%;margin-top:12px;padding:16px;border:0;border-radius:12px;background:#04933A;color:#ffffff;font-weight:800;font-size:17px;cursor:pointer;display:block;text-align:center;text-decoration:none}\n.ghost{background:#ffffff;color:#003F8F;border:1px solid #D7DEE8}\n.ok{display:none;background:#E8F6EC;color:#04933A;padding:10px;border-radius:10px;margin-bottom:10px;font-weight:700}\n.warn{background:#FEF3C7;color:#92400E;padding:10px;border-radius:10px;font-size:13px;margin-bottom:10px}\na{color:#003F8F;font-weight:800;text-decoration:none}\n.tot{font-size:22px;font-weight:800;text-align:center;margin:10px 0;padding:12px;background:#003F8F;color:#ffffff;border-radius:12px}\n.grid{display:grid;gap:10px;margin:16px 0}\n.kpi{display:grid;grid-template-columns:1fr 1fr;gap:8px}\n.kpi div{border:1px solid #D7DEE8;border-radius:12px;padding:10px;background:#ffffff}\n.kpi b{display:block;font-size:20px;color:#003F8F}\n.kpi span{font-size:12px;color:#667085}\n.qty{display:inline-flex;gap:6px;align-items:center;justify-content:center}\n.qty button{width:28px;height:28px;border:0;border-radius:8px;background:#003F8F;color:#ffffff;font-weight:800;cursor:pointer}\n.off-bar{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 12px}\n.off-bar a{font-size:12px;padding:8px 10px;border-radius:999px;background:#ffffff;border:1px solid #D7DEE8;color:#003F8F;font-weight:800}\n.sec{font-size:11px;font-weight:800;letter-spacing:.06em;color:#667085;margin:16px 0 6px;text-transform:uppercase}\n.grid.two{grid-template-columns:1fr 1fr}\n.atlas-search{width:100%;min-height:46px;padding:10px 12px;border:1px solid #D7DEE8;border-radius:12px;box-sizing:border-box;font:inherit;margin:0 0 8px;background:#ffffff;color:#111827}\n.atlas-search:focus{outline:2px solid #003F8F;border-color:#003F8F}\n.kpi-line{font-size:13px;font-weight:800;color:#111827;margin:0 0 10px}\n.atlas-group{display:block}\n.atlas-head{display:flex;width:100%;justify-content:space-between;align-items:center;margin:16px 0 6px;padding:0;border:0;background:transparent;color:#667085;font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;text-align:left;-webkit-appearance:none;appearance:none}\n.atlas-head small{color:#667085;font-weight:800}\n.atlas-list{display:none}\n.atlas-list.is-open{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:8px 0 16px}\n.atlas-item{display:block;width:100%;box-sizing:border-box;margin:0;padding:14px 10px;border:1px solid #D7DEE8;border-radius:12px;background:#ffffff;color:#003F8F;font-weight:800;text-align:center;text-decoration:none}\n.atlas-item.is-pos{border:0;background:#04933A;color:#fff}\n.atlas-item:active,.atlas-item:hover{filter:brightness(.98)}\n#quickDesk.grid.two .btn{margin-top:0}\n.hit-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}\n.hit-card{display:flex;flex-direction:column;align-items:flex-start;gap:4px;padding:10px;border:1px solid #D7DEE8;border-radius:12px;background:#ffffff;color:#111827;text-align:left;cursor:pointer;min-height:72px}\n.hit-card b{font-size:13px;line-height:1.3}\n.hit-card small{color:#667085;font-size:11px}\n.hit-card strong{color:#04933A;font-size:15px;margin-top:auto}\n.desk-sub{margin:0 0 10px;color:#667085;font-size:13px}\n\n</style>\n</head>\n<body>\n  <div class=\"wrap\">\n    <div class=\"card\">\n      <h1>নেট নেই — পুরো দোকান ফোনে চলবে</h1>\n      <p>অনলাইনে যে মডিউল আছে, অফলাইনেও সেই মেনুই থাকবে। ঘন ঘন কাজ উপরে, নিচে সম্পূর্ণ তালিকা। নেট ফিরলে সেভ সার্ভারে যাবে। টাকার হিসাব অফলাইনে বদলায় না।</p>\n      <div class=\"kpi\">\n        <div><span>অপেক্ষমাণ বিক্রয়</span><b id=\"sales\">0</b></div>\n        <div><span>অপেক্ষমাণ পেমেন্ট</span><b id=\"pays\">0</b></div>\n        <div><span>অপেক্ষমাণ অন্য কাজ</span><b id=\"writes\">0</b></div>\n        <div><span>ফোনে পণ্য</span><b id=\"prods\">0</b></div>\n      </div>\n      <p class=\"ok\" id=\"syncNote\" style=\"display:none\">নেট আছে — অপেক্ষমাণ কাজ সার্ভারে যাচ্ছে।</p>\n      <p class=\"warn\" id=\"catNote\">পণ্য তালিকা নেই। আগে একবার অনলাইনে যেকোনো পেজ খুলুন — তালিকা নিজে সেভ হবে। নতুন পণ্য POS থেকে হাতেও যোগ করা যায়।</p>\n      <div id=\"pendingBox\"></div>\n      <button class=\"btn\" type=\"button\" id=\"syncNow\">এখন সার্ভারে পাঠান</button>\n      <div class=\"sec\">দ্রুত কাজ — ফোনে চালু</div>\n      <div class=\"grid two\" id=\"quickDesk\">\n        <a class=\"btn\" href=\"/offline-sale.html\">বিক্রয় (POS)</a>\n        <a class=\"btn ghost\" href=\"/offline-payment.html\">কাস্টমার পেমেন্ট</a>\n        <a class=\"btn ghost\" href=\"/offline-customers.html\">কাস্টমার ও বকেয়া</a>\n        <a class=\"btn ghost\" href=\"/offline-sale.html\">পার্টস কাউন্টার</a>\n        <a class=\"btn ghost\" href=\"/offline-pulse.html\">আজকের অবস্থা</a>\n        <a class=\"btn ghost\" href=\"/offline-products.html\">পণ্য / স্টক / দাম</a>\n        <a class=\"btn ghost\" href=\"/offline-product-add.html\">নতুন পণ্য</a>\n        <a class=\"btn ghost\" href=\"/offline-purchase.html\">মাল ক্রয়</a>\n        <a class=\"btn ghost\" href=\"/offline-supplier-pay.html\">সাপ্লায়ার পেমেন্ট</a>\n        <a class=\"btn ghost\" href=\"/offline-module.html#m=hire-desk\">ভাড়া</a>\n        <a class=\"btn ghost\" href=\"/offline-workshop.html\">ওয়ার্কশপ জব</a>\n        <a class=\"btn ghost\" href=\"/offline-transfer.html\">অ্যাকাউন্ট ট্রান্সফার</a>\n        <a class=\"btn ghost\" href=\"/offline-expense.html\">খরচ</a>\n      </div>\n      <div class=\"sec\">সব মডিউল — অনলাইন মেন্যুর মতো</div>\n      <input type=\"search\" id=\"atlasQ\" class=\"atlas-search\" placeholder=\"মডিউল খুঁজুন — বিক্রয়, ভাড়া, হিসাব, সেটিংস…\" autocomplete=\"off\">\n      <p class=\"kpi-line\" id=\"atlasCount\">তালিকায় 154টি মডিউল</p>\n      <div id=\"atlasMount\">\n<section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>হোম ও দৈনিক</span><small>5</small></button><div class=\"atlas-list is-open\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:8px 0 16px\"><a class=\"atlas-item\" href=\"/offline.html\">হোম / ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-pulse.html\">আজকের অবস্থা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=live-work\">লাইভ ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=clipboard\">কপি-পোস্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=day-closing\">দিন শেষ</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>বিক্রয়</span><small>6</small></button><div class=\"atlas-list is-open\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:8px 0 16px\"><a class=\"atlas-item is-pos\" href=\"/offline-sale.html\">বিক্রয় (POS)</a><a class=\"atlas-item\" href=\"/offline-sale.html\">পার্টস কাউন্টার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sales-history\">বিক্রয় হিস্ট্রি</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sales-report\">বিক্রয় রিপোর্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sales-detailed\">বিস্তারিত বিক্রয়</a><a class=\"atlas-item\" href=\"/offline-module.html#m=items-report\">পণ্য অনুযায়ী বিক্রয়</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>বিক্রয় ফেরত</span><small>8</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=return-dash\">ফেরত ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=return-register\">ফেরত রেজিস্টার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=return-invoice\">ইনভয়েস ফেরত</a><a class=\"atlas-item\" href=\"/offline-module.html#m=return-manual\">ম্যানুয়াল ফেরত</a><a class=\"atlas-item\" href=\"/offline-module.html#m=return-exchange\">এক্সচেঞ্জ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=return-report\">ফেরত রিপোর্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=return-old-form\">পুরাতন ফেরত ফর্ম</a><a class=\"atlas-item\" href=\"/offline-module.html#m=return-old-hist\">পুরাতন ফেরত হিস্ট্রি</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>ক্রয়</span><small>4</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-purchase.html\">মাল ক্রয়</a><a class=\"atlas-item\" href=\"/offline-module.html#m=restock\">রিস্টক ইনভয়েস</a><a class=\"atlas-item\" href=\"/offline-module.html#m=purchase-hist\">ক্রয় হিস্ট্রি</a><a class=\"atlas-item\" href=\"/offline-module.html#m=purchase-report\">ক্রয় রিপোর্ট</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>ক্রয় ফেরত</span><small>4</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=pr-dash\">ক্রয় ফেরত ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=pr-register\">ক্রয় ফেরত রেজিস্টার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=pr-new\">নতুন ক্রয় ফেরত</a><a class=\"atlas-item\" href=\"/offline-module.html#m=pr-report\">ক্রয় ফেরত রিপোর্ট</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>স্টক ও পণ্য</span><small>16</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-products.html\">পণ্য / স্টক / দাম</a><a class=\"atlas-item\" href=\"/offline-product-add.html\">নতুন পণ্য</a><a class=\"atlas-item\" href=\"/offline-module.html#m=units\">ইউনিট ও রূপান্তর</a><a class=\"atlas-item\" href=\"/offline-module.html#m=unit-stock\">ইউনিট স্টক</a><a class=\"atlas-item\" href=\"/offline-module.html#m=old-battery\">পুরাতন ব্যাটারি</a><a class=\"atlas-item\" href=\"/offline-module.html#m=category\">ক্যাটাগরি</a><a class=\"atlas-item\" href=\"/offline-module.html#m=brand\">ব্র্যান্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=barcode\">বারকোড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=damage\">ক্ষতিগ্রস্ত স্টক</a><a class=\"atlas-item\" href=\"/offline-module.html#m=stock-now\">বর্তমান স্টক</a><a class=\"atlas-item\" href=\"/offline-module.html#m=stock-value\">স্টক মূল্য</a><a class=\"atlas-item\" href=\"/offline-module.html#m=stock-ledger\">স্টক লেজার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=stock-move\">স্টক চলাচল</a><a class=\"atlas-item\" href=\"/offline-module.html#m=product-perf\">পণ্য পারফরম্যান্স</a><a class=\"atlas-item\" href=\"/offline-module.html#m=stock-transfer\">স্টক ট্রান্সফার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=stock-count\">স্টক গণনা</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>ওয়ার্কশপ</span><small>8</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-workshop.html\">ওয়ার্কশপ জব</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ws-dash\">ওয়ার্কশপ ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ws-machines\">মেশিন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ws-finder\">পার্টস খোঁজা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ws-needs\">প্রয়োজন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ws-dues\">ওয়ার্কশপ বকেয়া</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ws-quotes\">কোটেশন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ws-serials\">সিরিয়াল</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>কাস্টমার</span><small>11</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-customers.html\">কাস্টমার ও বকেয়া</a><a class=\"atlas-item\" href=\"/offline-payment.html\">কাস্টমার পেমেন্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-new\">নতুন কাস্টমার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-withdraw\">কাস্টমার উত্তোলন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-pay-list\">পেমেন্ট তালিকা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-ledger\">কাস্টমার লেজার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-due\">বকেয়া নোটিফিকেশন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-status\">পেমেন্ট স্ট্যাটাস</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-area\">কাস্টমার এলাকা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-group\">কাস্টমার গ্রুপ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cust-ageing\">বকেয়া বয়স</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>ভাড়া</span><small>8</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=hire-desk\">কাস্টমার ভাড়া</a><a class=\"atlas-item\" href=\"/offline-module.html#m=hire-all\">সব চুক্তি</a><a class=\"atlas-item\" href=\"/offline-module.html#m=hire-now\">চলমান ভাড়া</a><a class=\"atlas-item\" href=\"/offline-module.html#m=shop-rent\">দোকান ভাড়া ডেস্ক</a><a class=\"atlas-item\" href=\"/offline-module.html#m=shop-rent-new\">নতুন দোকান ভাড়া</a><a class=\"atlas-item\" href=\"/offline-module.html#m=shop-rent-pay\">দোকান ভাড়া পেমেন্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=shop-rent-docs\">ভাড়া ডকুমেন্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=shop-rent-st\">ভাড়া স্টেটমেন্ট</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>সাপ্লায়ার</span><small>10</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-supplier-pay.html\">সাপ্লায়ার পেমেন্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-dash\">সাপ্লায়ার ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-list\">সাপ্লায়ার তালিকা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-new\">নতুন সাপ্লায়ার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-pay-list\">সাপ্লায়ার পেমেন্ট তালিকা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-ledger\">সাপ্লায়ার লেজার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-statement\">সাপ্লায়ার স্টেটমেন্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-ageing\">দেনা বয়স</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-sign\">সাপ্লায়ার চিহ্ন যাচাই</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sup-guard\">ব্যালেন্স পাহারা (লক)</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>লেনদেন ও হিসাব</span><small>15</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-expense.html\">খরচ</a><a class=\"atlas-item\" href=\"/offline-transfer.html\">অ্যাকাউন্ট ট্রান্সফার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=daily-audit\">দৈনিক অডিট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=txn-type\">খরচ / আয় ধরন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=finance\">আমার ফিনান্স</a><a class=\"atlas-item\" href=\"/offline-module.html#m=txn-general\">সাধারণ লেনদেন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=txn-receive\">বাহির থেকে রিসিভ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=txn-family\">পরিবারের সদস্য</a><a class=\"atlas-item\" href=\"/offline-module.html#m=txn-accounts\">হিসাব তালিকা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cash-book\">ক্যাশ বই</a><a class=\"atlas-item\" href=\"/offline-module.html#m=cash-bank\">ক্যাশ / ব্যাংক সারাংশ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=income-exp\">আয় ব্যয়</a><a class=\"atlas-item\" href=\"/offline-module.html#m=bank-st\">ব্যাংক স্টেটমেন্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=net-pl\">নিট লাভ-ক্ষতি</a><a class=\"atlas-item\" href=\"/offline-module.html#m=vat\">ভ্যাট / ট্যাক্স</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>পার্টনার ও ঋণ</span><small>2</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=partner-dash\">পার্টনারশিপ ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=bloan\">ব্যবসার ঋণ</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>রিপোর্ট ও ওয়ারেন্টি</span><small>3</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=report-dash\">রিপোর্ট ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=warranty-search\">ওয়ারেন্টি খোঁজ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=warranty-report\">ওয়ারেন্টি রিপোর্ট</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>কর্মী</span><small>3</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=hrm-list\">কর্মী তালিকা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=hrm-ledger\">কর্মী লেজার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=hrm-pay\">কর্মী পেমেন্ট</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>পরিবার ও অন্যান্য</span><small>9</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=family-dash\">পারিবারিক ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=family-members\">পরিবারের সদস্য</a><a class=\"atlas-item\" href=\"/offline-module.html#m=family-contacts\">পারিবারিক কন্টাক্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=family-health\">স্বাস্থ্য</a><a class=\"atlas-item\" href=\"/offline-module.html#m=family-shop\">পারিবারিক কেনাকাটা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=family-cal\">পারিবারিক ক্যালেন্ডার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=contacts\">কন্টাক্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=personal\">ব্যক্তিগত</a><a class=\"atlas-item\" href=\"/offline-module.html#m=shared-bills\">শেয়ার্ড বিল</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>স্মার্ট ও এজেন্ট</span><small>10</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-dash\">স্মার্ট ড্যাশবোর্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-assistant\">অ্যাসিস্ট্যান্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-stock\">স্মার্ট স্টক</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-purchase\">স্মার্ট ক্রয়</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-customers\">স্মার্ট কাস্টমার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-profit\">স্মার্ট লাভ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-calendar\">স্মার্ট ক্যালেন্ডার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-map\">ম্যাপ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=smart-privacy\">প্রাইভেসি</a><a class=\"atlas-item\" href=\"/offline-module.html#m=agents\">এজেন্ট</a></div></section><section class=\"atlas-group\"><button type=\"button\" class=\"atlas-head\"><span>সেটিংস</span><small>32</small></button><div class=\"atlas-list\" style=\"display:none\"><a class=\"atlas-item\" href=\"/offline-module.html#m=file-atlas\">ফাইল খাতা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=theme\">রং ও ডিজাইন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=shop-info\">দোকানের তথ্য</a><a class=\"atlas-item\" href=\"/offline-module.html#m=pos-title\">POS শিরোনাম</a><a class=\"atlas-item\" href=\"/offline-module.html#m=layout\">লেআউট ডিজাইন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=text-style\">লেখা বড় ছোট ও রঙ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=stores\">স্টোর</a><a class=\"atlas-item\" href=\"/offline-module.html#m=ticker\">টিকার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=countdown\">কাউন্টডাউন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=banners\">হোম ব্যানার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=trust\">ট্রাস্ট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=provenance\">প্রোভেন্যান্স</a><a class=\"atlas-item\" href=\"/offline-module.html#m=invoice-tpl\">ইনভয়েস টেমপ্লেট</a><a class=\"atlas-item\" href=\"/offline-module.html#m=super-admin\">সুপার অ্যাডমিন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=roles\">রোল কন্ট্রোল</a><a class=\"atlas-item\" href=\"/offline-module.html#m=users\">সিস্টেম ইউজার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=user-add\">নতুন ইউজার</a><a class=\"atlas-item\" href=\"/offline-module.html#m=user-perm\">ইউজার পারমিশন</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sms-setup\">এসএমএস সেটআপ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=sms-log\">এসএমএস লগ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=activity\">অ্যাকটিভিটি লগ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=audit\">অডিট ট্রেইল</a><a class=\"atlas-item\" href=\"/offline-module.html#m=speed\">স্পিড সিস্টেম</a><a class=\"atlas-item\" href=\"/offline-module.html#m=project-care\">প্রজেক্ট রক্ষা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=money-guard\">টাকা মিল</a><a class=\"atlas-item\" href=\"/offline-module.html#m=health\">সিস্টেম হেলথ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=backup\">ব্যাকআপ</a><a class=\"atlas-item\" href=\"/offline-module.html#m=lang\">ভাষা</a><a class=\"atlas-item\" href=\"/offline-module.html#m=tools\">টুলস</a><a class=\"atlas-item\" href=\"/offline-module.html#m=password\">পাসওয়ার্ড</a><a class=\"atlas-item\" href=\"/offline-module.html#m=profile\">প্রোফাইল</a><a class=\"atlas-item\" href=\"/offline-module.html#m=about\">অ্যাবাউট</a></div></section>\n      </div>\n    </div>\n  </div>\n<script>\n\n(function(g){\n  function read(k){ try{ var v=JSON.parse(localStorage.getItem(k)||'[]'); return Array.isArray(v)?v:[]; }catch(e){ return []; } }\n  function write(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }\n  if (!g.AmeOfflineCatalog) {\n    g.AmeOfflineCatalog = {\n      loadProducts: function(){ return read('ame_offline_products'); },\n      loadCustomers: function(){ return read('ame_offline_customers'); },\n      loadAccounts: function(){ return read('ame_offline_accounts'); },\n      searchProducts: function(q){\n        q=String(q||'').trim().toLowerCase(); if(!q) return [];\n        return this.loadProducts().filter(function(p){\n          return ((p.name||'')+' '+(p.sku||'')+' '+(p.barcode||'')+' '+p.id).toLowerCase().indexOf(q)!==-1;\n        });\n      }\n    };\n  }\n  if (!g.AmeOfflineQueue) {\n    g.AmeOfflineQueue = {\n      makeRef: function(){ return 'OFF-'+Date.now()+'-'+Math.random().toString(36).slice(2,8); },\n      sendSale: function(payload){\n        var ref = (payload && payload.offline_client_ref) || this.makeRef();\n        var q = read('ame_offline_sales_queue');\n        q.push({ client_ref: ref, queued_at: new Date().toISOString(), payload: Object.assign({}, payload||{}, { offline_client_ref: ref }) });\n        write('ame_offline_sales_queue', q);\n        return Promise.resolve({ queued: true, ref: ref });\n      }\n    };\n  }\n  if (g.navigator && g.navigator.serviceWorker) {\n    try { g.navigator.serviceWorker.register('/sw.js?v=10.98.799'); } catch (e) {}\n  }\n})(window);\n\n</script>\n<script>\n/**\n * Offline shop atlas — the same modules as the online sidebar.\n * Desk items work on the phone. Other items open a module shell\n * and the live PHP page when the network returns.\n */\n(function (global) {\n  'use strict';\n\n  function item(id, title, href, online, desk) {\n    return { id: id, title: title, href: href, online: online, desk: !!desk };\n  }\n  function desk(id, title, href, online) {\n    return item(id, title, href, online, true);\n  }\n  function view(id, title, online) {\n    return item(id, title, '/offline-module.html#m=' + encodeURIComponent(id), online, false);\n  }\n\n  var groups = [\n    {\n      id: 'daily',\n      title: 'হোম ও দৈনিক',\n      items: [\n        desk('home', 'হোম / ড্যাশবোর্ড', '/offline.html', '/index.php'),\n        desk('pulse', 'আজকের অবস্থা', '/offline-pulse.html', '/modules/pulse/index.php'),\n        view('live-work', 'লাইভ ড্যাশবোর্ড', '/modules/reports/live_work.php'),\n        view('clipboard', 'কপি-পোস্ট', '/modules/clipboard/index.php'),\n        view('day-closing', 'দিন শেষ', '/modules/reports/day_closing.php')\n      ]\n    },\n    {\n      id: 'sales',\n      title: 'বিক্রয়',\n      items: [\n        desk('pos', 'বিক্রয় (POS)', '/offline-sale.html', '/modules/sales/pos.php'),\n        desk('parts', 'পার্টস কাউন্টার', '/offline-sale.html', '/modules/sales/pos.php'),\n        view('sales-history', 'বিক্রয় হিস্ট্রি', '/modules/sales/history.php'),\n        view('sales-report', 'বিক্রয় রিপোর্ট', '/modules/reports/sales_report.php'),\n        view('sales-detailed', 'বিস্তারিত বিক্রয়', '/modules/reports/sales_detailed.php'),\n        view('items-report', 'পণ্য অনুযায়ী বিক্রয়', '/modules/reports/items_report.php')\n      ]\n    },\n    {\n      id: 'sale-return',\n      title: 'বিক্রয় ফেরত',\n      items: [\n        view('return-dash', 'ফেরত ড্যাশবোর্ড', '/modules/returns/v2/dashboard.php'),\n        view('return-register', 'ফেরত রেজিস্টার', '/modules/returns/v2/register.php'),\n        view('return-invoice', 'ইনভয়েস ফেরত', '/modules/returns/v2/create_invoice_return.php'),\n        view('return-manual', 'ম্যানুয়াল ফেরত', '/modules/returns/v2/create_manual_return.php'),\n        view('return-exchange', 'এক্সচেঞ্জ', '/modules/returns/v2/create_exchange.php'),\n        view('return-report', 'ফেরত রিপোর্ট', '/modules/returns/return_report.php'),\n        view('return-old-form', 'পুরাতন ফেরত ফর্ম', '/modules/returns/add.php'),\n        view('return-old-hist', 'পুরাতন ফেরত হিস্ট্রি', '/modules/returns/history.php')\n      ]\n    },\n    {\n      id: 'purchase',\n      title: 'ক্রয়',\n      items: [\n        desk('purchase', 'মাল ক্রয়', '/offline-purchase.html', '/modules/purchase/add.php'),\n        view('restock', 'রিস্টক ইনভয়েস', '/modules/inventory/restock_invoice.php'),\n        view('purchase-hist', 'ক্রয় হিস্ট্রি', '/modules/purchase/history.php'),\n        view('purchase-report', 'ক্রয় রিপোর্ট', '/modules/reports/purchase_summary.php')\n      ]\n    },\n    {\n      id: 'purchase-return',\n      title: 'ক্রয় ফেরত',\n      items: [\n        view('pr-dash', 'ক্রয় ফেরত ড্যাশবোর্ড', '/modules/purchase/returns/dashboard.php'),\n        view('pr-register', 'ক্রয় ফেরত রেজিস্টার', '/modules/purchase/returns/register.php'),\n        view('pr-new', 'নতুন ক্রয় ফেরত', '/modules/purchase/returns/create.php'),\n        view('pr-report', 'ক্রয় ফেরত রিপোর্ট', '/modules/purchase/returns/analytics.php')\n      ]\n    },\n    {\n      id: 'inventory',\n      title: 'স্টক ও পণ্য',\n      items: [\n        desk('stock', 'পণ্য / স্টক / দাম', '/offline-products.html', '/modules/inventory/list.php'),\n        desk('product-add', 'নতুন পণ্য', '/offline-product-add.html', '/modules/inventory/add_product.php'),\n        view('units', 'ইউনিট ও রূপান্তর', '/modules/inventory/unit_setup.php'),\n        view('unit-stock', 'ইউনিট স্টক', '/modules/inventory/unit_stock.php'),\n        view('old-battery', 'পুরাতন ব্যাটারি', '/modules/inventory/old_battery.php'),\n        view('category', 'ক্যাটাগরি', '/modules/inventory/categories.php'),\n        view('brand', 'ব্র্যান্ড', '/modules/inventory/brands.php'),\n        view('barcode', 'বারকোড', '/modules/inventory/barcode.php'),\n        view('damage', 'ক্ষতিগ্রস্ত স্টক', '/modules/inventory/damage.php'),\n        view('stock-now', 'বর্তমান স্টক', '/modules/inventory/stock_report.php'),\n        view('stock-value', 'স্টক মূল্য', '/modules/reports/valuation.php'),\n        view('stock-ledger', 'স্টক লেজার', '/modules/reports/stock_ledger.php'),\n        view('stock-move', 'স্টক চলাচল', '/modules/reports/stock_movement_analysis.php'),\n        view('product-perf', 'পণ্য পারফরম্যান্স', '/modules/reports/product_performance.php'),\n        view('stock-transfer', 'স্টক ট্রান্সফার', '/modules/inventory/transfer.php'),\n        view('stock-count', 'স্টক গণনা', '/modules/inventory/stock_count.php')\n      ]\n    },\n    {\n      id: 'workshop',\n      title: 'ওয়ার্কশপ',\n      items: [\n        desk('ws-job', 'ওয়ার্কশপ জব', '/offline-workshop.html', '/modules/workshop/job_new.php'),\n        view('ws-dash', 'ওয়ার্কশপ ড্যাশবোর্ড', '/modules/workshop/index.php'),\n        view('ws-machines', 'মেশিন', '/modules/workshop/machines.php'),\n        view('ws-finder', 'পার্টস খোঁজা', '/modules/workshop/parts_finder.php'),\n        view('ws-needs', 'প্রয়োজন', '/modules/workshop/needs.php'),\n        view('ws-dues', 'ওয়ার্কশপ বকেয়া', '/modules/workshop/dues.php'),\n        view('ws-quotes', 'কোটেশন', '/modules/workshop/quotes.php'),\n        view('ws-serials', 'সিরিয়াল', '/modules/workshop/serials.php')\n      ]\n    },\n    {\n      id: 'customers',\n      title: 'কাস্টমার',\n      items: [\n        desk('customers', 'কাস্টমার ও বকেয়া', '/offline-customers.html', '/modules/customers/index.php'),\n        desk('cust-pay', 'কাস্টমার পেমেন্ট', '/offline-payment.html', '/modules/customers/payment-receive.php'),\n        view('cust-new', 'নতুন কাস্টমার', '/modules/customers/add_customer.php'),\n        view('cust-withdraw', 'কাস্টমার উত্তোলন', '/modules/customers/withdraw.php'),\n        view('cust-pay-list', 'পেমেন্ট তালিকা', '/modules/customers/actions/payments-list.php'),\n        view('cust-ledger', 'কাস্টমার লেজার', '/modules/customers/ledger.php'),\n        view('cust-due', 'বকেয়া নোটিফিকেশন', '/modules/customers/due-reminder.php'),\n        view('cust-status', 'পেমেন্ট স্ট্যাটাস', '/modules/customers/actions/payment-status.php'),\n        view('cust-area', 'কাস্টমার এলাকা', '/modules/customers/customer-areas.php'),\n        view('cust-group', 'কাস্টমার গ্রুপ', '/modules/customers/customer-groups.php'),\n        view('cust-ageing', 'বকেয়া বয়স', '/modules/reports/receivable_ageing.php')\n      ]\n    },\n    {\n      id: 'hire',\n      title: 'ভাড়া',\n      items: [\n        view('hire-desk', 'কাস্টমার ভাড়া', '/modules/customers/hire/index.php'),\n        view('hire-all', 'সব চুক্তি', '/chuktis.php'),\n        view('hire-now', 'চলমান ভাড়া', '/now.php'),\n        view('shop-rent', 'দোকান ভাড়া ডেস্ক', '/modules/shop_rent/index.php'),\n        view('shop-rent-new', 'নতুন দোকান ভাড়া', '/modules/shop_rent/shop.php'),\n        view('shop-rent-pay', 'দোকান ভাড়া পেমেন্ট', '/modules/shop_rent/pay.php'),\n        view('shop-rent-docs', 'ভাড়া ডকুমেন্ট', '/modules/shop_rent/locker.php'),\n        view('shop-rent-st', 'ভাড়া স্টেটমেন্ট', '/modules/shop_rent/statement.php')\n      ]\n    },\n    {\n      id: 'suppliers',\n      title: 'সাপ্লায়ার',\n      items: [\n        desk('sup-pay', 'সাপ্লায়ার পেমেন্ট', '/offline-supplier-pay.html', '/modules/suppliers/pay.php'),\n        view('sup-dash', 'সাপ্লায়ার ড্যাশবোর্ড', '/modules/suppliers/dashboard.php'),\n        view('sup-list', 'সাপ্লায়ার তালিকা', '/modules/suppliers/list.php'),\n        view('sup-new', 'নতুন সাপ্লায়ার', '/modules/suppliers/profile.php?id=0'),\n        view('sup-pay-list', 'সাপ্লায়ার পেমেন্ট তালিকা', '/modules/suppliers/payments-list.php'),\n        view('sup-ledger', 'সাপ্লায়ার লেজার', '/modules/suppliers/ledger.php'),\n        view('sup-statement', 'সাপ্লায়ার স্টেটমেন্ট', '/modules/suppliers/statement.php'),\n        view('sup-ageing', 'দেনা বয়স', '/modules/reports/payable_ageing.php'),\n        view('sup-sign', 'সাপ্লায়ার চিহ্ন যাচাই', '/modules/suppliers/sign_check.php'),\n        view('sup-guard', 'ব্যালেন্স পাহারা (লক)', '/modules/suppliers/balance_guard.php')\n      ]\n    },\n    {\n      id: 'accounts',\n      title: 'লেনদেন ও হিসাব',\n      items: [\n        desk('expense', 'খরচ', '/offline-expense.html', '/modules/accounts/add_transaction.php'),\n        desk('transfer', 'অ্যাকাউন্ট ট্রান্সফার', '/offline-transfer.html', '/modules/accounts/transfer.php'),\n        view('daily-audit', 'দৈনিক অডিট', '/modules/accounts/daily_audit.php'),\n        view('txn-type', 'খরচ / আয় ধরন', '/modules/accounts/categories.php'),\n        view('finance', 'আমার ফিনান্স', '/modules/accounts/finance_dashboard.php'),\n        view('txn-general', 'সাধারণ লেনদেন', '/modules/accounts/add_transaction.php'),\n        view('txn-receive', 'বাহির থেকে রিসিভ', '/modules/accounts/receive.php'),\n        view('txn-family', 'পরিবারের সদস্য', '/modules/accounts/family_members.php'),\n        view('txn-accounts', 'হিসাব তালিকা', '/modules/accounts/list.php'),\n        view('cash-book', 'ক্যাশ বই', '/modules/accounts/cash_book.php'),\n        view('cash-bank', 'ক্যাশ / ব্যাংক সারাংশ', '/modules/reports/cash_bank_summary.php'),\n        view('income-exp', 'আয় ব্যয়', '/modules/reports/finance_summary.php'),\n        view('bank-st', 'ব্যাংক স্টেটমেন্ট', '/modules/accounts/bank_statement.php'),\n        view('net-pl', 'নিট লাভ-ক্ষতি', '/modules/accounts/net_profit_report.php'),\n        view('vat', 'ভ্যাট / ট্যাক্স', '/modules/accounts/vat_tax_summary.php')\n      ]\n    },\n    {\n      id: 'partners',\n      title: 'পার্টনার ও ঋণ',\n      items: [\n        view('partner-dash', 'পার্টনারশিপ ড্যাশবোর্ড', '/modules/accounts/partner_central_dashboard.php'),\n        view('bloan', 'ব্যবসার ঋণ', '/modules/bloan/desk.php')\n      ]\n    },\n    {\n      id: 'reports',\n      title: 'রিপোর্ট ও ওয়ারেন্টি',\n      items: [\n        view('report-dash', 'রিপোর্ট ড্যাশবোর্ড', '/modules/reports/index.php'),\n        view('warranty-search', 'ওয়ারেন্টি খোঁজ', '/modules/reports/warranty.php'),\n        view('warranty-report', 'ওয়ারেন্টি রিপোর্ট', '/modules/reports/warranty_report.php')\n      ]\n    },\n    {\n      id: 'hrm',\n      title: 'কর্মী',\n      items: [\n        view('hrm-list', 'কর্মী তালিকা', '/modules/hrm/employee_list.php'),\n        view('hrm-ledger', 'কর্মী লেজার', '/modules/hrm/worker_ledger.php'),\n        view('hrm-pay', 'কর্মী পেমেন্ট', '/modules/hrm/worker_pay.php')\n      ]\n    },\n    {\n      id: 'family',\n      title: 'পরিবার ও অন্যান্য',\n      items: [\n        view('family-dash', 'পারিবারিক ড্যাশবোর্ড', '/modules/family/index.php'),\n        view('family-members', 'পরিবারের সদস্য', '/modules/family/members.php'),\n        view('family-contacts', 'পারিবারিক কন্টাক্ট', '/modules/family/contacts.php'),\n        view('family-health', 'স্বাস্থ্য', '/modules/family/doctors.php'),\n        view('family-shop', 'পারিবারিক কেনাকাটা', '/modules/family/shopping.php'),\n        view('family-cal', 'পারিবারিক ক্যালেন্ডার', '/modules/family/calendar.php'),\n        view('contacts', 'কন্টাক্ট', '/modules/contacts/list.php'),\n        view('personal', 'ব্যক্তিগত', '/modules/personal/index.php'),\n        view('shared-bills', 'শেয়ার্ড বিল', '/modules/utilities/shared_bills.php')\n      ]\n    },\n    {\n      id: 'smart',\n      title: 'স্মার্ট ও এজেন্ট',\n      items: [\n        view('smart-dash', 'স্মার্ট ড্যাশবোর্ড', '/modules/smart/index.php'),\n        view('smart-assistant', 'অ্যাসিস্ট্যান্ট', '/modules/smart/assistant.php'),\n        view('smart-stock', 'স্মার্ট স্টক', '/modules/smart/stock.php'),\n        view('smart-purchase', 'স্মার্ট ক্রয়', '/modules/smart/purchase.php'),\n        view('smart-customers', 'স্মার্ট কাস্টমার', '/modules/smart/customers.php'),\n        view('smart-profit', 'স্মার্ট লাভ', '/modules/smart/profit.php'),\n        view('smart-calendar', 'স্মার্ট ক্যালেন্ডার', '/modules/smart/calendar.php'),\n        view('smart-map', 'ম্যাপ', '/modules/smart/map.php'),\n        view('smart-privacy', 'প্রাইভেসি', '/modules/smart/privacy.php'),\n        view('agents', 'এজেন্ট', '/modules/agents/index.php')\n      ]\n    },\n    {\n      id: 'settings',\n      title: 'সেটিংস',\n      items: [\n        view('file-atlas', 'ফাইল খাতা', '/modules/settings/file_atlas.php'),\n        view('theme', 'রং ও ডিজাইন', '/modules/settings/theme.php'),\n        view('shop-info', 'দোকানের তথ্য', '/modules/settings/dashboard_settings.php'),\n        view('pos-title', 'POS শিরোনাম', '/modules/settings/pos_title.php'),\n        view('layout', 'লেআউট ডিজাইন', '/modules/settings/layout_designer.php'),\n        view('text-style', 'লেখা বড় ছোট ও রঙ', '/modules/settings/text_style.php'),\n        view('stores', 'স্টোর', '/modules/settings/stores.php'),\n        view('ticker', 'টিকার', '/modules/settings/scrolling_text.php'),\n        view('countdown', 'কাউন্টডাউন', '/modules/settings/countdown.php'),\n        view('banners', 'হোম ব্যানার', '/modules/settings/banners.php'),\n        view('trust', 'ট্রাস্ট', '/modules/settings/trust.php'),\n        view('provenance', 'প্রোভেন্যান্স', '/modules/provenance/index.php'),\n        view('invoice-tpl', 'ইনভয়েস টেমপ্লেট', '/modules/settings/invoice_template.php'),\n        view('super-admin', 'সুপার অ্যাডমিন', '/modules/settings/super_admin.php'),\n        view('roles', 'রোল কন্ট্রোল', '/modules/settings/role_control.php'),\n        view('users', 'সিস্টেম ইউজার', '/modules/settings/users.php'),\n        view('user-add', 'নতুন ইউজার', '/modules/settings/user_add.php'),\n        view('user-perm', 'ইউজার পারমিশন', '/modules/settings/role_permissions.php'),\n        view('sms-setup', 'এসএমএস সেটআপ', '/modules/settings/sms_config.php'),\n        view('sms-log', 'এসএমএস লগ', '/modules/settings/sms_log.php'),\n        view('activity', 'অ্যাকটিভিটি লগ', '/modules/settings/activity_logs.php'),\n        view('audit', 'অডিট ট্রেইল', '/modules/reports/audit_trail.php'),\n        view('speed', 'স্পিড সিস্টেম', '/modules/settings/speed_system.php'),\n        view('project-care', 'প্রজেক্ট রক্ষা', '/modules/settings/project_care.php'),\n        view('money-guard', 'টাকা মিল', '/modules/settings/money_guard.php'),\n        view('health', 'সিস্টেম হেলথ', '/modules/settings/system_health.php'),\n        view('backup', 'ব্যাকআপ', '/modules/settings/backup.php'),\n        view('lang', 'ভাষা', '/modules/settings/lang_settings.php'),\n        view('tools', 'টুলস', '/modules/settings/tools.php'),\n        view('password', 'পাসওয়ার্ড', '/modules/settings/change_password.php'),\n        view('profile', 'প্রোফাইল', '/modules/settings/profile.php'),\n        view('about', 'অ্যাবাউট', '/modules/settings/about.php')\n      ]\n    }\n  ];\n\n  var quick = [\n    desk('pos', 'বিক্রয় (POS)', '/offline-sale.html', '/modules/sales/pos.php'),\n    desk('cust-pay', 'কাস্টমার পেমেন্ট', '/offline-payment.html', '/modules/customers/payment-receive.php'),\n    desk('customers', 'কাস্টমার ও বকেয়া', '/offline-customers.html', '/modules/customers/index.php'),\n    desk('parts', 'পার্টস কাউন্টার', '/offline-sale.html', '/modules/sales/pos.php'),\n    desk('pulse', 'আজকের অবস্থা', '/offline-pulse.html', '/modules/pulse/index.php'),\n    desk('stock', 'পণ্য / স্টক / দাম', '/offline-products.html', '/modules/inventory/list.php'),\n    desk('product-add', 'নতুন পণ্য', '/offline-product-add.html', '/modules/inventory/add_product.php'),\n    desk('purchase', 'মাল ক্রয়', '/offline-purchase.html', '/modules/purchase/add.php'),\n    desk('sup-pay', 'সাপ্লায়ার পেমেন্ট', '/offline-supplier-pay.html', '/modules/suppliers/pay.php'),\n    view('hire-desk', 'ভাড়া', '/modules/customers/hire/index.php'),\n    desk('ws-job', 'ওয়ার্কশপ জব', '/offline-workshop.html', '/modules/workshop/job_new.php'),\n    desk('transfer', 'অ্যাকাউন্ট ট্রান্সফার', '/offline-transfer.html', '/modules/accounts/transfer.php'),\n    desk('expense', 'খরচ', '/offline-expense.html', '/modules/accounts/add_transaction.php')\n  ];\n\n  function allItems() {\n    var out = [];\n    var seen = {};\n    groups.forEach(function (g) {\n      (g.items || []).forEach(function (it) {\n        if (!it || !it.id || seen[it.id]) return;\n        seen[it.id] = true;\n        out.push(it);\n      });\n    });\n    return out;\n  }\n\n  function find(id) {\n    var list = allItems();\n    for (var i = 0; i < list.length; i++) {\n      if (list[i].id === id) return list[i];\n    }\n    for (var q = 0; q < quick.length; q++) {\n      if (quick[q].id === id) return quick[q];\n    }\n    return null;\n  }\n\n  function findByOnline(path) {\n    var want = String(path || '').split('?')[0];\n    var list = allItems();\n    for (var i = 0; i < list.length; i++) {\n      var on = String(list[i].online || '').split('?')[0];\n      if (on && on === want) return list[i];\n    }\n    return null;\n  }\n\n  function search(query) {\n    var q = String(query || '').trim().toLowerCase();\n    if (!q) return allItems();\n    return allItems().filter(function (it) {\n      return (it.title + ' ' + (it.online || '') + ' ' + it.id).toLowerCase().indexOf(q) !== -1;\n    });\n  }\n\n  global.AmeOfflineAtlas = {\n    version: '10.98.791',\n    groups: groups,\n    quick: quick,\n    allItems: allItems,\n    find: find,\n    findByOnline: findByOnline,\n    search: search\n  };\n})(window);\n\n</script>\n<script>\n/**\n * Offline menu uses the same button colors as the live shop hub:\n * gradient POS, white ghost buttons, two-column groups.\n */\n(function (global) {\n  'use strict';\n\n  var CSS_ID = 'ame-offline-atlas-css';\n  var BTN = 'display:block;width:100%;box-sizing:border-box;margin:0;padding:14px 10px;border:0;border-radius:12px;background:#04933A;color:#ffffff;font-weight:800;text-align:center;text-decoration:none';\n  var GHOST = 'display:block;width:100%;box-sizing:border-box;margin:0;padding:14px 10px;border:1px solid #D7DEE8;border-radius:12px;background:#ffffff;color:#003F8F;font-weight:800;text-align:center;text-decoration:none';\n  var GRID = 'display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:8px 0 16px';\n  var GRID_OFF = 'display:none;margin:0';\n  var SEC = 'display:flex;justify-content:space-between;align-items:center;width:100%;box-sizing:border-box;margin:16px 0 6px;padding:0;border:0;background:transparent;color:#64748b;font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;text-align:left;cursor:pointer;-webkit-appearance:none;appearance:none';\n\n  function esc(text) {\n    return String(text || '')\n      .replace(/&/g, '&amp;')\n      .replace(/</g, '&lt;')\n      .replace(/>/g, '&gt;')\n      .replace(/\"/g, '&quot;');\n  }\n\n  function injectCss() {\n    if (!global.document || global.document.getElementById(CSS_ID)) return;\n    var el = global.document.createElement('style');\n    el.id = CSS_ID;\n    el.textContent = [\n      'body{background:#F4F7FB;color:#111827}',\n      '.atlas-search{width:100%;min-height:46px;padding:10px 12px;border:1px solid #D7DEE8;border-radius:12px;box-sizing:border-box;font:inherit;margin:0 0 8px;background:#ffffff;color:#111827}',\n      '.atlas-group{display:block;width:100%}',\n      '.atlas-head{display:flex !important;width:100%;justify-content:space-between;align-items:center;margin:16px 0 6px;padding:0;border:0;background:transparent;color:#64748b;font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;-webkit-appearance:none;appearance:none}',\n      '.atlas-head small{color:#64748b;font-weight:800}',\n      '.atlas-list{display:none}',\n      '.atlas-list.is-open{display:grid !important;grid-template-columns:1fr 1fr;gap:10px;margin:8px 0 16px}',\n      '.atlas-item,.atlas-item:visited{display:block !important;width:100%;box-sizing:border-box;margin:0;padding:14px 10px;border:1px solid #D7DEE8;border-radius:12px;background:#ffffff;color:#003F8F !important;font-weight:800;text-align:center;text-decoration:none}',\n      '.atlas-item.is-pos,.atlas-item.is-pos:visited{border:0;background:#04933A;color:#ffffff !important}',\n      '#quickDesk.grid.two .btn{margin-top:0}',\n      '#quickDesk a.btn,#quickDesk a.btn.ghost{color:inherit}'\n    ].join('\\n');\n    (global.document.head || global.document.documentElement).appendChild(el);\n  }\n\n  function itemHref(it) {\n    if (global.AmeOfflineLive && global.AmeOfflineLive.href) return global.AmeOfflineLive.href(it);\n    if (it.desk) return it.href || '/offline.html';\n    return '/offline-module.html#m=' + encodeURIComponent(it.id || '');\n  }\n\n  function itemHtml(it) {\n    var pos = it.id === 'pos';\n    var cls = pos ? 'atlas-item is-pos' : 'atlas-item';\n    var style = pos ? BTN : GHOST;\n    return '<a class=\"' + cls + '\" href=\"' + esc(itemHref(it)) + '\" style=\"' + style + '\">' + esc(it.title) + '</a>';\n  }\n\n  function render(root, query) {\n    injectCss();\n    if (!root || !global.AmeOfflineAtlas) return 0;\n    var atlas = global.AmeOfflineAtlas;\n    var q = String(query || '').trim();\n    var html = '';\n    var count = 0;\n    if (q) {\n      var hits = atlas.search(q);\n      html += '<button type=\"button\" class=\"atlas-head\" style=\"' + SEC + '\">খোঁজ <small>' + hits.length + '</small></button>';\n      html += '<div class=\"atlas-list is-open\" style=\"' + GRID + '\">';\n      hits.forEach(function (it) { html += itemHtml(it); });\n      html += '</div>';\n      count = hits.length;\n    } else {\n      (atlas.groups || []).forEach(function (g, i) {\n        var items = g.items || [];\n        var open = i < 2;\n        count += items.length;\n        html += '<section class=\"atlas-group\" data-group=\"' + esc(g.id) + '\">';\n        html += '<button type=\"button\" class=\"atlas-head\" aria-expanded=\"' + (open ? 'true' : 'false') + '\" style=\"' + SEC + '\">'\n          + '<span>' + esc(g.title) + '</span><small>' + items.length + '</small></button>';\n        html += '<div class=\"atlas-list' + (open ? ' is-open' : '') + '\" style=\"' + (open ? GRID : GRID_OFF) + '\">';\n        items.forEach(function (it) { html += itemHtml(it); });\n        html += '</div></section>';\n      });\n    }\n    root.innerHTML = html;\n    return count;\n  }\n\n  function bind(root) {\n    injectCss();\n    if (!root || root.dataset.ameAtlasBound === '1') return;\n    root.dataset.ameAtlasBound = '1';\n    root.addEventListener('click', function (ev) {\n      var head = ev.target.closest('.atlas-head');\n      if (!head || !root.contains(head)) return;\n      ev.preventDefault();\n      var group = head.closest('.atlas-group');\n      var list = group && group.querySelector('.atlas-list');\n      if (!list) return;\n      var open = !list.classList.contains('is-open');\n      list.classList.toggle('is-open', open);\n      list.setAttribute('style', open ? GRID : GRID_OFF);\n      head.setAttribute('aria-expanded', open ? 'true' : 'false');\n    });\n  }\n\n  function paintQuick(root) {\n    injectCss();\n    if (!root || !global.AmeOfflineAtlas) return;\n    var html = '';\n    (global.AmeOfflineAtlas.quick || []).forEach(function (it, i) {\n      var cls = i === 0 ? 'btn' : 'btn ghost';\n      var style = i === 0 ? BTN : GHOST;\n      html += '<a class=\"' + cls + '\" href=\"' + esc(itemHref(it)) + '\" style=\"' + style + '\">' + esc(it.title) + '</a>';\n    });\n    root.innerHTML = html;\n  }\n\n  global.AmeOfflineHub = { render: render, bind: bind, paintQuick: paintQuick };\n})(window);\n\n</script>\n<script>\nfunction reads(k){try{return JSON.parse(localStorage.getItem(k)||'[]')}catch(e){return []}}\nfunction n(a,f){try{return (window[a]&&window[a][f])?window[a][f]():0}catch(e){return 0}}\nfunction paint(){\n  var sales=n('AmeOfflineQueue','pendingCount')||reads('ame_offline_sales_queue').length;\n  var pays=n('AmeOfflinePay','pendingCount')||reads('ame_offline_pay_queue').length;\n  var writes=n('AmeOfflineWrite','pendingCount')||reads('ame_offline_write_queue').length;\n  var prods=reads('ame_offline_products');\n  document.getElementById('sales').textContent=sales;\n  document.getElementById('pays').textContent=pays;\n  document.getElementById('writes').textContent=writes;\n  document.getElementById('prods').textContent=prods.length;\n  document.getElementById('catNote').style.display=prods.length?'none':'block';\n  document.getElementById('syncNote').style.display=navigator.onLine?'block':'none';\n}\nfunction paintAtlas(){\n  if (window.AmeOfflineHub && window.AmeOfflineAtlas) {\n    AmeOfflineHub.paintQuick(document.getElementById('quickDesk'));\n    AmeOfflineHub.bind(document.getElementById('atlasMount'));\n    var q=(document.getElementById('atlasQ')&&document.getElementById('atlasQ').value)||'';\n    var count=AmeOfflineHub.render(document.getElementById('atlasMount'), q);\n    var box=document.getElementById('atlasCount');\n    if (box) box.textContent='তালিকায় '+AmeOfflineAtlas.allItems().length+'টি মডিউল'+(q?' · দেখাচ্ছি '+count+'টি':'');\n  }\n}\ndocument.addEventListener('click', function(e){\n  var h=e.target.closest && e.target.closest('.atlas-head');\n  if(!h) return;\n  var list=h.parentNode && h.parentNode.querySelector('.atlas-list');\n  if(!list) return;\n  e.preventDefault();\n  var open=list.classList.toggle('is-open');\n  list.style.display=open?'grid':'none';\n});\nvar qEl=document.getElementById('atlasQ');\nif(qEl) qEl.addEventListener('input', paintAtlas);\ndocument.getElementById('syncNow').addEventListener('click', function(){\n  if(!navigator.onLine){ alert('আগে ইন্টারনেট চালু করুন'); return; }\n  if(window.AmeOfflineSync) AmeOfflineSync.all();\n  document.getElementById('syncNote').style.display='block';\n});\npaint();\npaintAtlas();\nsetTimeout(paintAtlas, 50);\n</script>\n</body>\n</html>\n";
}

function htmlResponse(html) {
  return new Response(html, {
    status: 200,
    headers: { 'Content-Type': 'text/html; charset=utf-8' }
  });
}

function cssResponse(css) {
  return new Response(css == null ? '/* offline */' : css, {
    status: 200,
    headers: { 'Content-Type': 'text/css; charset=utf-8' }
  });
}

function jsResponse(js) {
  return new Response(js == null ? '/* offline */' : js, {
    status: 200,
    headers: { 'Content-Type': 'application/javascript; charset=utf-8' }
  });
}

async function copyForwardCaches(dest) {
  const keys = await caches.keys();
  for (const key of keys) {
    if (key === cacheName || key.indexOf('ame-pwa-') !== 0) continue;
    try {
      const old = await caches.open(key);
      const reqs = await old.keys();
      for (const r of reqs) {
        if (await dest.match(r)) continue;
        const res = await old.match(r);
        if (res) {
          try { await dest.put(r, res); } catch (err) {}
        }
      }
    } catch (err) {}
  }
}

async function cacheHasShell(name) {
  try {
    const cache = await caches.open(name);
    return !!(await cache.match('/offline-sale.html') || await cache.match('/offline.html'));
  } catch (e) {
    return false;
  }
}

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    await copyForwardCaches(cache);
    await cache.put('/offline.html', htmlResponse(hubHtml()));
    await cache.put('/offline-sale.html', htmlResponse(saleHtml()));
    await cache.put(self.location.origin + '/offline.html', htmlResponse(hubHtml()));
    await cache.put(self.location.origin + '/offline-sale.html', htmlResponse(saleHtml()));
    await Promise.all(staticAssets.map(async (url) => {
      try {
        const res = await fetch(url, { credentials: 'same-origin', cache: 'reload' });
        const abs = new URL(url, self.location.origin);
        if (res && res.ok && shouldCache(abs, res)) {
          await cache.put(abs.href, res.clone());
          await cache.put(abs.pathname, res.clone());
        }
      } catch (err) {}
    }));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    if (self.registration.navigationPreload) {
      try { await self.registration.navigationPreload.enable(); } catch (err) {}
    }
    const ready = await cacheHasShell(cacheName);
    const keys = (await caches.keys()).filter((key) => key.indexOf('ame-pwa-') === 0).sort();
    const keep = ready ? keys.slice(-2) : keys;
    await Promise.all(keys.map((key) => {
      if (key === cacheName) return null;
      if (keep.indexOf(key) !== -1) return null;
      return caches.delete(key);
    }));
    self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') {
    return;
  }
  const url = new URL(req.url);
  if (url.origin !== location.origin) {
    return;
  }
  if (isDownloadPath(url.pathname)) {
    e.respondWith(fetch(req, { cache: 'no-store', credentials: 'same-origin' }));
    return;
  }
  if (isHireListPath(url.pathname)) {
    e.respondWith(networkThenModule(req, e.preloadResponse));
    return;
  }
  if (isAuthPath(url.pathname)) {
    e.respondWith(networkOnlyAuth(req));
    return;
  }
  if (isPaymentUrl(url)) {
    e.respondWith(paymentPage(req, e.preloadResponse));
    return;
  }
  if (isPosUrl(url)) {
    e.respondWith(posPage(req, e.preloadResponse));
    return;
  }
  const isPhp = url.pathname.endsWith('.php') || url.pathname.endsWith('/');
  const isAppAsset = url.pathname.indexOf('/assets/') !== -1
      || url.pathname.endsWith('.html')
      || url.pathname.endsWith('.js')
      || url.pathname.endsWith('.css');
  if (isPhp) {
    e.respondWith(networkFirst(req, e.preloadResponse));
  } else if (isAppAsset) {
    e.respondWith(cacheFirst(req));
  } else {
    e.respondWith(cacheFirst(req));
  }
});

async function networkOnlyAuth(req) {
  try {
    return await fetch(req, { cache: 'no-store' });
  } catch (e) {
    return htmlResponse('<!DOCTYPE html><html lang="bn"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>অফলাইন</title></head><body style="font-family:sans-serif;padding:20px;text-align:center"><h1>নেট সংযোগ দরকার</h1><p>লগইন ও পাসওয়ার্ড রিসেটের জন্য ইন্টারনেট চালু করুন।</p></body></html>');
  }
}

async function cacheFirst(req) {
  const cache = await caches.open(cacheName);
  const path = new URL(req.url).pathname || '';
  const cached = await fromAnyCache(req);
  if (cached && assetBodyOk(path, cached)) {
    fetchTimeout(req, 4000).then(function (fresh) {
      if (fresh && fresh.ok && shouldCache(new URL(req.url), fresh)) {
        cache.put(req, fresh.clone()).catch(function () {});
        cache.put(path, fresh.clone()).catch(function () {});
      }
    }).catch(function () {});
    return cached;
  }
  try {
    const fresh = await fetchTimeout(req, 4000);
    if (fresh && fresh.ok && shouldCache(new URL(req.url), fresh)) {
      try {
        await cache.put(req, fresh.clone());
        await cache.put(path, fresh.clone());
      } catch (err) {}
    }
    if (fresh) return fresh;
  } catch (e) {}
  if (cached && assetBodyOk(path, cached)) return cached;
  return fallbackFor(req, cache);
}

async function remember(cache, req, fresh) {
  if (req.method === 'GET' && fresh && shouldCache(new URL(req.url), fresh)) {
    try { await cache.put(req, fresh.clone()); } catch (e) {}
  }
  return fresh;
}

async function matchPage(cache, path) {
  return await cache.match(path, { ignoreSearch: true })
    || await cache.match(self.location.origin + path, { ignoreSearch: true })
    || await cache.match('.' + path)
    || null;
}

async function fromCache(cache, req) {
  const url = new URL(req.url);
  return await cache.match(req, { ignoreSearch: true, ignoreVary: true })
    || await matchPage(cache, url.pathname)
    || null;
}

async function fromAnyCache(req) {
  const keys = await caches.keys();
  const ordered = keys.filter((key) => key.indexOf('ame-pwa-') === 0).sort().reverse();
  if (ordered[0] !== cacheName) {
    ordered.unshift(cacheName);
  }
  const path = new URL(req.url).pathname || '';
  for (const key of ordered) {
    try {
      const cache = await caches.open(key);
      const hit = await fromCache(cache, req);
      if (hit && assetBodyOk(path, hit)) return hit;
    } catch (err) {}
  }
  return null;
}

async function matchAnyShell(path) {
  const keys = await caches.keys();
  const ordered = keys.filter((key) => key.indexOf('ame-pwa-') === 0).sort().reverse();
  ordered.unshift(cacheName);
  for (const key of ordered) {
    try {
      const cache = await caches.open(key);
      const hit = await matchPage(cache, path);
      if (hit) return hit;
    } catch (err) {}
  }
  return null;
}

function fetchTimeout(req, ms, extra) {
  extra = extra || {};
  const ctrl = new AbortController();
  const timer = setTimeout(function () {
    try { ctrl.abort(); } catch (err) {}
  }, ms);
  const opts = Object.assign({ credentials: 'same-origin' }, extra, { signal: ctrl.signal });
  return fetch(req, opts).finally(function () { clearTimeout(timer); });
}

async function fallbackFor(req, cache) {
  const url = new URL(req.url);
  const path = url.pathname || '';
  // Never return HTML for stylesheets/scripts — browsers then render an unstyled hub.
  if (path.endsWith('.css')) {
    return (await fromCache(cache, req)) || cssResponse();
  }
  if (path.endsWith('.js')) {
    return (await fromCache(cache, req)) || jsResponse();
  }
  if (isPaymentUrl(url)) {
    return (await matchAnyShell('/offline-payment.html'))
      || htmlResponse(hubHtml());
  }
  if (isPosUrl(url)) {
    return (await matchAnyShell('/offline-sale.html'))
      || (await matchAnyShell('/offline.html'))
      || htmlResponse(saleHtml());
  }
  if (path.indexOf('/modules/customers/') !== -1) {
    return (await matchAnyShell('/offline-customers.html'))
      || (await matchAnyShell('/offline.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/inventory/add_product.php') !== -1) {
    return (await fromAnyCache(req))
      || (await matchAnyShell('/offline-product-add.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/inventory/') !== -1) {
    return (await matchAnyShell('/offline-products.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/purchase/') !== -1) {
    return (await matchAnyShell('/offline-purchase.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/expenses/') !== -1) {
    return (await matchAnyShell('/offline-expense.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/workshop/') !== -1) {
    return (await matchAnyShell('/offline-workshop.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/suppliers/') !== -1) {
    return (await matchAnyShell('/offline-supplier-pay.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/accounts/') !== -1) {
    return (await matchAnyShell('/offline-transfer.html'))
      || htmlResponse(hubHtml());
  }
  if (path.indexOf('/modules/pulse/') !== -1) {
    return (await matchAnyShell('/offline-pulse.html'))
      || htmlResponse(hubHtml());
  }
  if (isHomePath(path) || path.indexOf('/offline-') === 0) {
    return (await matchAnyShell(path))
      || (await matchAnyShell('/offline.html'))
      || htmlResponse(hubHtml());
  }
  const wantsHtml = req.mode === 'navigate'
    || ((req.headers.get('accept') || '').indexOf('text/html') !== -1);
  if (wantsHtml && path.indexOf('/modules/') === 0) {
    return (await matchAnyShell('/offline-module.html'))
      || (await matchAnyShell('/offline.html'))
      || htmlResponse(hubHtml());
  }
  if (wantsHtml) {
    return (await matchAnyShell('/offline.html'))
      || htmlResponse(hubHtml());
  }
  return (await fromCache(cache, req))
    || new Response('', { status: 404, statusText: 'offline-miss' });
}

async function takePreload(preloadP) {
  if (!preloadP) return null;
  try {
    return await preloadP;
  } catch (e) {
    return null;
  }
}

async function networkFirst(req, preloadP) {
  const cache = await caches.open(cacheName);
  try {
    const fresh = (await takePreload(preloadP)) || await fetchTimeout(req, 2500, { cache: 'no-store' });
    await remember(cache, req, fresh);
    return fresh;
  } catch (e) {
    const path = new URL(req.url).pathname || '';
    if (isHomePath(path)) {
      return (await matchAnyShell('/offline.html')) || htmlResponse(hubHtml());
    }
    const cached = await fromAnyCache(req);
    if (cached) return cached;
    return fallbackFor(req, cache);
  }
}

async function paymentPage(req, preloadP) {
  const cache = await caches.open(cacheName);
  const cached = (await fromAnyCache(req)) || (await matchAnyShell('/offline-payment.html'));
  const path = new URL(req.url).pathname || '';
  const isShell = path.indexOf('offline-payment.html') !== -1;
  if (isShell && cached) {
    fetchTimeout(req, 4000).then(function (fresh) { remember(cache, req, fresh); }).catch(function () {});
    return cached;
  }
  try {
    const fresh = (await takePreload(preloadP)) || await fetchTimeout(req, 2500, { cache: 'no-store' });
    if (fresh && fresh.ok) {
      await remember(cache, req, fresh);
      return fresh;
    }
  } catch (e) {}
  return cached || htmlResponse(hubHtml());
}

async function networkThenModule(req, preloadP) {
  try {
    const fresh = (await takePreload(preloadP)) || await fetchTimeout(req, 2500, { cache: 'no-store', credentials: 'same-origin' });
    return fresh;
  } catch (e) {
    return (await matchAnyShell('/offline-module.html'))
      || (await matchAnyShell('/offline.html'))
      || htmlResponse(hubHtml());
  }
}

function saleHtml() {
  return "<!DOCTYPE html>\n<html lang=\"bn\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>পার্টস কাউন্টার</title>\n<style>\n/* Offline POS — same desk as live pos.php (two-column counter). */\n:root {\n  --desk-navy: #003F8F;\n  --desk-blue: #1565C0;\n  --desk-green: #04933A;\n  --desk-canvas: #F4F7FB;\n  --desk-line: #D7DEE8;\n  --desk-text: #111827;\n  --desk-muted: #667085;\n}\nhtml, body {\n  margin: 0;\n  background: var(--desk-canvas);\n  color: var(--desk-text);\n  font-family: \"Noto Sans Bengali\", \"Noto Sans\", system-ui, sans-serif;\n}\nhtml.ame-phone-desktop body {\n  min-width: 1366px;\n  background: var(--desk-canvas);\n}\n#main-content { min-height: 100vh; }\n.ame-pos-page { padding: 6px 10px 16px; box-sizing: border-box; }\n.ame-pos-shell { width: 100%; }\n.ame-pos-grid {\n  display: grid !important;\n  grid-template-columns: minmax(0, 2.3fr) minmax(280px, 0.85fr) !important;\n  gap: 10px;\n  align-items: start;\n  width: 100%;\n}\n@media (max-width: 900px) {\n  html:not(.ame-phone-desktop) .ame-pos-grid {\n    grid-template-columns: 1fr !important;\n  }\n}\n\n.ame-desk-bar {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-height: 42px;\n  margin: 0 0 8px;\n  padding: 6px 10px;\n  background: var(--desk-navy);\n  color: #fff;\n  border-radius: 8px;\n}\n.ame-desk-bar a, .ame-desk-bar button {\n  color: #fff;\n  background: transparent;\n  border: 1px solid rgba(255,255,255,.35);\n  border-radius: 8px;\n  min-height: 32px;\n  padding: 4px 10px;\n  font-weight: 800;\n  text-decoration: none;\n  cursor: pointer;\n  font-size: 13px;\n}\n.ame-desk-marquee {\n  flex: 1;\n  min-width: 0;\n  overflow: hidden;\n  font-weight: 800;\n  white-space: nowrap;\n}\n.ame-desk-clockbox {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-weight: 800;\n  font-variant-numeric: tabular-nums;\n  white-space: nowrap;\n}\n\n.ame-pos-card {\n  background: #fff;\n  border: 1px solid var(--desk-line);\n  border-radius: 10px;\n  padding: 8px 10px;\n  box-sizing: border-box;\n}\n.ame-pos-price-row { display: flex; gap: 8px; margin: 0 0 8px; }\n.ame-pos-mode {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 36px;\n  height: 36px;\n  border: 1px solid var(--desk-line);\n  border-radius: 8px;\n  background: #fff;\n  font-weight: 900;\n  cursor: pointer;\n}\n.ame-pos-mode input { display: none; }\n.ame-pos-mode.is-on {\n  background: var(--desk-blue);\n  border-color: var(--desk-blue);\n  color: #fff;\n}\n\n.ame-pos-term-bar {\n  display: grid;\n  grid-template-columns: minmax(220px, 0.38fr) minmax(0, 0.62fr);\n  gap: 10px;\n  align-items: start;\n}\n.ame-desk-card-head {\n  font-size: 13px;\n  font-weight: 800;\n  margin: 0 0 6px;\n}\n.ame-pos-radios {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px 12px;\n  margin: 0 0 8px;\n  font-size: 13px;\n  font-weight: 700;\n}\n.ame-pos-radios label { display: flex; align-items: center; gap: 4px; cursor: pointer; }\n.ame-pos-input, .ame-desk-date-input, select.ame-pos-input {\n  width: 100%;\n  min-height: 38px;\n  padding: 6px 10px;\n  border: 1px solid var(--desk-line);\n  border-radius: 8px;\n  box-sizing: border-box;\n  font: inherit;\n  background: #fff;\n}\n.pos-customer-picker { display: flex; gap: 6px; align-items: center; }\n.pos-customer-picker .ame-pos-input { flex: 1; }\n.ame-saved-customer-btn, .ame-cashlist-ok {\n  min-width: 38px;\n  min-height: 38px;\n  border: 1px solid var(--desk-line);\n  border-radius: 8px;\n  background: #fff;\n  font-weight: 800;\n  cursor: pointer;\n}\n.ame-cashlist-ok { color: var(--desk-green); border-color: var(--desk-green); }\n.ame-search-zikir {\n  margin: 0 0 4px;\n  font-size: 12px;\n  font-weight: 800;\n  color: var(--desk-navy);\n}\n.ame-pos-search { position: relative; }\n#search-res {\n  display: none;\n  position: absolute;\n  left: 0; right: 0;\n  z-index: 30;\n  max-height: 280px;\n  overflow: auto;\n  background: #fff;\n  border: 1px solid var(--desk-line);\n  border-radius: 0 0 8px 8px;\n  box-shadow: 0 12px 28px rgba(17,24,39,.12);\n}\n#search-res.is-open { display: block; }\n#search-res .res-item {\n  display: block;\n  width: 100%;\n  text-align: left;\n  padding: 8px 10px;\n  border: 0;\n  border-bottom: 1px solid #F1F5F9;\n  background: #fff;\n  cursor: pointer;\n  font: inherit;\n}\n#search-res .res-item:hover { background: #EFF6FF; }\n#search-res .res-item small { display: block; color: var(--desk-muted); font-size: 12px; }\n.ame-pos-search-subline { margin-top: 6px; }\n.pos-customer-add {\n  border: 0;\n  background: transparent;\n  color: var(--desk-navy);\n  font-weight: 800;\n  cursor: pointer;\n  padding: 0;\n}\n\n.ame-desk-table-head {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 8px;\n  margin: 8px 0 6px;\n  font-weight: 800;\n}\n.ame-pos-table-wrap {\n  overflow: auto;\n  border: 1px solid var(--desk-line);\n  background: #fff;\n  min-height: 160px;\n}\n.table-pos { width: 100%; border-collapse: collapse; }\n.table-pos th {\n  background: var(--desk-blue);\n  color: #fff;\n  font-size: 12px;\n  font-weight: 800;\n  padding: 6px 4px;\n  text-align: center;\n}\n.table-pos td {\n  border-bottom: 1px solid var(--desk-line);\n  padding: 4px;\n  text-align: center;\n  font-size: 13px;\n  height: 32px;\n}\n.table-pos input[type=\"number\"], .table-pos input[type=\"text\"] {\n  width: 100%;\n  min-height: 28px;\n  border: 1px solid var(--desk-line);\n  border-radius: 6px;\n  text-align: center;\n  box-sizing: border-box;\n}\n.ame-desk-remove {\n  width: 28px; height: 28px; border: 0; border-radius: 8px;\n  background: #FDECEC; color: #D92D20; font-weight: 800; cursor: pointer;\n}\n.ame-pos-add-row {\n  margin-top: 6px;\n  width: 100%;\n  min-height: 34px;\n  border: 1px dashed var(--desk-line);\n  border-radius: 8px;\n  background: #fff;\n  font-weight: 800;\n  cursor: pointer;\n}\n.warn {\n  display: none;\n  margin: 6px 0;\n  padding: 8px 10px;\n  border-radius: 8px;\n  background: #FFF7E6;\n  color: #92400E;\n  font-weight: 700;\n  font-size: 13px;\n}\n.ok {\n  display: none;\n  margin: 6px 0;\n  padding: 8px 10px;\n  border-radius: 8px;\n  background: #ECFDF3;\n  color: #067647;\n  font-weight: 800;\n}\n\n.ame-pos-summary { display: flex; flex-direction: column; gap: 8px; }\n.ame-desk-box {\n  background: #fff;\n  border: 1px solid var(--desk-line);\n  border-radius: 10px;\n  padding: 0 10px 10px;\n}\n.ame-desk-box h3 {\n  margin: 0 -10px 8px;\n  padding: 8px 10px;\n  background: var(--desk-navy);\n  color: #fff;\n  border-radius: 10px 10px 0 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n.ame-desk-box label {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 8px;\n  margin: 6px 0;\n  font-size: 13px;\n  font-weight: 700;\n}\n.ame-desk-box input, .ame-desk-box select, .ame-desk-box output {\n  font-weight: 800;\n}\n.ame-desk-box input, .ame-desk-box select {\n  width: 120px;\n  max-width: 48%;\n  min-height: 32px;\n  padding: 4px 6px;\n  border: 1px solid var(--desk-line);\n  border-radius: 8px;\n  box-sizing: border-box;\n}\n.ame-desk-box > input, .ame-desk-box > select { width: 100%; max-width: none; }\n.ame-desk-grand { background: var(--desk-navy); color: #fff; text-align: center; }\n.ame-desk-grand h3 { background: transparent; }\n.ame-desk-grand strong { display: block; font-size: 24px; color: #fff; }\n.ame-desk-actions { display: flex; flex-direction: column; gap: 8px; }\n#amePosCompleteBtn, .ame-pos-complete {\n  width: 100%;\n  min-height: 48px;\n  border: 0;\n  border-radius: 10px;\n  background: var(--desk-blue);\n  color: #fff;\n  font-size: 16px;\n  font-weight: 800;\n  cursor: pointer;\n}\n.ame-desk-draft {\n  min-height: 36px;\n  border: 1px solid var(--desk-line);\n  border-radius: 10px;\n  background: #fff;\n  color: var(--desk-blue);\n  font-weight: 800;\n  cursor: pointer;\n}\n.ame-desk-sms {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  font-size: 12px;\n  font-weight: 700;\n  color: var(--desk-muted);\n}\n.pos-customer-suggest {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  max-height: 180px;\n  overflow: auto;\n  border: 1px solid var(--desk-line);\n  border-radius: 8px;\n  background: #fff;\n}\n.pos-customer-suggest button {\n  display: block;\n  width: 100%;\n  text-align: left;\n  padding: 8px 10px;\n  border: 0;\n  border-bottom: 1px solid #F1F5F9;\n  background: #fff;\n  cursor: pointer;\n  font: inherit;\n}\n.pos-customer-suggest button:hover { background: #EFF6FF; }\n.hit-card { display: none; }\n\n</style>\n<script>\nwindow.amePhoneDesktopSite=function(){var ua=navigator.userAgent||'',touch=navigator.maxTouchPoints>0;try{if(window.matchMedia&&window.matchMedia('(pointer: coarse)').matches)touch=true;}catch(e){}if(!touch)return false;var s=Math.min(screen.width||0,screen.height||0);return s>0&&s<=540;};\nwindow.ameApplySaleDesktopViewport=function(){if(!window.amePhoneDesktopSite())return;document.documentElement.classList.add('ame-phone-desktop');var d=1366,w=Math.min(window.innerWidth||d,screen.width||d);var sc=Math.max(0.2,Math.min(1,w/d));var m=document.querySelector('meta[name=viewport]');if(m)m.setAttribute('content','width='+d+', initial-scale='+sc.toFixed(4)+', minimum-scale=0.2, maximum-scale=5, user-scalable=yes, viewport-fit=cover');};\nwindow.ameApplySaleDesktopViewport();\n</script>\n</head>\n<body class=\"ame-pos-terminal-page ame-sales-pro ame-sale-pro ame-sale-desk\">\n\n  <div id=\"main-content\">\n    <div class=\"ame-pos-page ame-sale-pro ame-sale-desk\">\n      <div class=\"ame-desk-bar\">\n        <button type=\"button\" id=\"ameDeskMenuBtn\">সাইডবার খুলুন</button>\n        <div class=\"ame-desk-marquee\" id=\"amePosTitleLine\">APONSHOP · পার্টস কাউন্টার</div>\n        <div class=\"ame-desk-clockbox\">\n          <strong id=\"ameDeskClock\">--:--:--</strong>\n          <span id=\"ameDeskDate\"></span>\n        </div>\n      </div>\n      <div class=\"ame-pos-shell\">\n        <main class=\"ame-pos-grid\">\n          <div class=\"ame-desk-stack\">\n            <section class=\"ame-pos-card ame-pos-term-top\">\n              <div class=\"ame-pos-price-row\" id=\"posPriceModeBar\">\n                <label class=\"ame-pos-mode is-on\" title=\"খুচরা\"><input type=\"radio\" name=\"price_mode\" value=\"retail\" checked><span>K</span></label>\n                <label class=\"ame-pos-mode\" title=\"পাইকারি\"><input type=\"radio\" name=\"price_mode\" value=\"wholesale\"><span>P</span></label>\n                <label class=\"ame-pos-mode\" title=\"ডিলার\"><input type=\"radio\" name=\"price_mode\" value=\"dealer\"><span>D</span></label>\n              </div>\n              <div class=\"ame-pos-term-bar\">\n                <div class=\"ame-pos-term-controls\">\n                  <div class=\"ame-desk-card-head\">ক্রেতা / সাপ্লায়ার</div>\n                  <div class=\"ame-pos-radios\" id=\"posToolbarCustomerRadios\">\n                    <label><input type=\"radio\" name=\"cus_type_toolbar\" value=\"Retail\" checked> রিটেইল ক্রেতা</label>\n                    <label><input type=\"radio\" name=\"cus_type_toolbar\" value=\"Registered\"> নিবন্ধিত ক্রেতা</label>\n                    <label><input type=\"radio\" name=\"cus_type_toolbar\" value=\"Supplier\"> সাপ্লায়ার</label>\n                  </div>\n                  <div class=\"pos-customer-picker\" id=\"posCustomerBox\">\n                    <input type=\"text\" id=\"posCustomerInfoField\" class=\"ame-pos-input\" placeholder=\"ক্রেতার তথ্য\" autocomplete=\"off\">\n                    <button type=\"button\" class=\"ame-cashlist-ok\" title=\"ক্যাশলিস্ট\">✓</button>\n                  </div>\n                  <ul id=\"posCustomerSearchList\" class=\"pos-customer-suggest\" hidden></ul>\n                </div>\n                <div class=\"ame-pos-term-search\">\n                  <p class=\"ame-search-zikir\">(পাস -আনফাস যিকির হচ্ছে কি?)</p>\n                  <div class=\"ame-pos-search\">\n                    <input type=\"search\" id=\"p-search\" class=\"ame-pos-input\" placeholder=\"যন্ত্রাংশের নাম বা কোড...\" autocomplete=\"off\">\n                    <div id=\"search-res\"></div>\n                  </div>\n                  <div class=\"ame-pos-search-subline\">\n                    <button type=\"button\" id=\"openQuickCustomer\" class=\"pos-customer-add\">➕ নতুন ক্রেতা যোগ</button>\n                  </div>\n                  <div class=\"warn\" id=\"warn\">পণ্য তালিকা নেই। আগে একবার অনলাইনে যেকোনো পেজ খুলুন — তালিকা ফোনে সেভ হবে।</div>\n                  <div class=\"ok\" id=\"okBox\"></div>\n                </div>\n              </div>\n            </section>\n            <section class=\"ame-pos-card ame-pos-term-cart\">\n              <div class=\"ame-desk-table-head\">\n                <strong>পণ্য তালিকা</strong>\n                <button type=\"button\" class=\"pos-customer-add\" id=\"ameCustomAddHint\">+ নতুন পণ্য যোগ করুন</button>\n              </div>\n              <div class=\"ame-pos-table-wrap\">\n                <table class=\"table-pos\">\n                  <thead>\n                    <tr>\n                      <th>ক্রম</th>\n                      <th></th>\n                      <th>পণ্য কোড</th>\n                      <th>পণ্যের নাম</th>\n                      <th>পরিমাণ</th>\n                      <th>দাম (৳)</th>\n                      <th>ছাড় (%)</th>\n                      <th>লাইন মোট (৳)</th>\n                      <th>অ্যাকশন</th>\n                    </tr>\n                  </thead>\n                  <tbody id=\"cart-body\"></tbody>\n                </table>\n              </div>\n              <button type=\"button\" class=\"ame-pos-add-row\" id=\"ameAddProductRow\">আরেকটি পণ্যের সারি যোগ করুন</button>\n            </section>\n          </div>\n          <aside id=\"amePosPay\" class=\"ame-pos-card ame-pos-summary\">\n            <section class=\"ame-desk-box\">\n              <h3>বিক্রয়ের তারিখ</h3>\n              <input id=\"ameSaleDate\" class=\"ame-desk-date-input\" type=\"date\">\n            </section>\n            <section class=\"ame-desk-box\" id=\"ameDeskRunBal\">\n              <h3>এই বিক্রয়ের পর</h3>\n              <p id=\"deskRunTag\" style=\"margin:8px 0 0;font-weight:800;\">সমান</p>\n              <output id=\"deskRunAmount\" style=\"display:block;font-size:22px;font-weight:800;\">0.00</output>\n            </section>\n            <section class=\"ame-desk-box\">\n              <h3>মোট ও ছাড়</h3>\n              <label>সাব-টোটাল (৳)<output id=\"deskSubtotal\">0.00</output></label>\n              <label>ছাড় (৳)<input id=\"deskDiscountTaka\" type=\"number\" min=\"0\" step=\"0.01\" value=\"0\"></label>\n              <label>ছাড়ের পর (৳)<output id=\"deskAfter\">0.00</output></label>\n              <label>রাউন্ডিং (+/-)<input id=\"rounding\" type=\"number\" step=\"0.01\" value=\"0\"></label>\n            </section>\n            <section class=\"ame-desk-box ame-desk-paybox\">\n              <h3>পেমেন্ট</h3>\n              <section class=\"ame-desk-box ame-desk-grand\">\n                <h3>সর্বমোট পাওনা</h3>\n                <strong id=\"deskGrand\">৳ 0.00</strong>\n              </section>\n              <label>টাকা (৳)<input id=\"deskPaid\" type=\"number\" min=\"0\" step=\"0.01\" value=\"0\"></label>\n              <label>চেঞ্জ (৳)<output id=\"deskChange\">0.00</output></label>\n              <label>আপনার অ্যাকাউন্ট<select id=\"deskPayMethod\"></select></label>\n              <label>বাকি (৳)<output id=\"deskDue\">0.00</output></label>\n            </section>\n            <section class=\"ame-desk-box\">\n              <h3>পরবর্তী পেমেন্ট</h3>\n              <label>তারিখ<input id=\"ameNextPayDate\" class=\"ame-desk-date-input\" type=\"date\"></label>\n              <label>কত টাকা দেবে (৳)<input id=\"ameNextPayAmount\" type=\"number\" min=\"0\" step=\"0.01\" placeholder=\"0.00\"></label>\n            </section>\n            <section class=\"ame-desk-actions\">\n              <button type=\"button\" class=\"ame-pos-complete\" id=\"amePosCompleteBtn\" onclick=\"submitFinalSale()\">বিক্রয় সম্পন্ন করুন</button>\n              <button type=\"button\" class=\"ame-desk-draft\" id=\"ameDeskDraftBack\">ড্রাফটে ফিরে যান</button>\n              <label class=\"ame-desk-sms\"><span>SMS পাঠান (ঐচ্ছিক)</span><input type=\"checkbox\" id=\"send-sms\"></label>\n            </section>\n          </aside>\n        </main>\n      </div>\n    </div>\n  </div>\n  \n<script>\n\n(function(g){\n  function read(k){ try{ var v=JSON.parse(localStorage.getItem(k)||'[]'); return Array.isArray(v)?v:[]; }catch(e){ return []; } }\n  function write(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }\n  if (!g.AmeOfflineCatalog) {\n    g.AmeOfflineCatalog = {\n      loadProducts: function(){ return read('ame_offline_products'); },\n      loadCustomers: function(){ return read('ame_offline_customers'); },\n      loadAccounts: function(){ return read('ame_offline_accounts'); },\n      searchProducts: function(q){\n        q=String(q||'').trim().toLowerCase(); if(!q) return [];\n        return this.loadProducts().filter(function(p){\n          return ((p.name||'')+' '+(p.sku||'')+' '+(p.barcode||'')+' '+p.id).toLowerCase().indexOf(q)!==-1;\n        });\n      }\n    };\n  }\n  if (!g.AmeOfflineQueue) {\n    g.AmeOfflineQueue = {\n      makeRef: function(){ return 'OFF-'+Date.now()+'-'+Math.random().toString(36).slice(2,8); },\n      sendSale: function(payload){\n        var ref = (payload && payload.offline_client_ref) || this.makeRef();\n        var q = read('ame_offline_sales_queue');\n        q.push({ client_ref: ref, queued_at: new Date().toISOString(), payload: Object.assign({}, payload||{}, { offline_client_ref: ref }) });\n        write('ame_offline_sales_queue', q);\n        return Promise.resolve({ queued: true, ref: ref });\n      }\n    };\n  }\n  if (g.navigator && g.navigator.serviceWorker) {\n    try { g.navigator.serviceWorker.register('/sw.js?v=10.98.799'); } catch (e) {}\n  }\n})(window);\n\n</script>\n<script>\n(function (global) {\n  'use strict';\n\n  var cart = [];\n  var products = [];\n  var customers = [];\n  var accounts = [];\n  var customerId = 0;\n  var customerName = '';\n  var customerDue = 0;\n  var priceMode = 'retail';\n\n  function $(id) { return document.getElementById(id); }\n  function esc(t) {\n    return String(t || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\"/g, '&quot;');\n  }\n  function num(n) { return Number(n) || 0; }\n  function money(n) {\n    return num(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });\n  }\n  function todayInput() {\n    var d = new Date();\n    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');\n  }\n  function todayLabel() {\n    var d = new Date();\n    return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();\n  }\n  function priceOf(p) {\n    if (priceMode === 'wholesale') return num(p.wholesale_price || p.sale_price);\n    if (priceMode === 'dealer') return num(p.dealer_price || p.sale_price);\n    return num(p.sale_price || p.current_price);\n  }\n  function fromLs(key) {\n    try {\n      var v = JSON.parse(localStorage.getItem(key) || '[]');\n      return Array.isArray(v) ? v : [];\n    } catch (e) { return []; }\n  }\n  function loadLocal() {\n    try { products = (global.AmeOfflineCatalog && AmeOfflineCatalog.loadProducts()) || fromLs('ame_offline_products'); } catch (e) { products = fromLs('ame_offline_products'); }\n    try { customers = (global.AmeOfflineCatalog && AmeOfflineCatalog.loadCustomers()) || fromLs('ame_offline_customers'); } catch (e) { customers = fromLs('ame_offline_customers'); }\n    try { accounts = (global.AmeOfflineCatalog && AmeOfflineCatalog.loadAccounts()) || fromLs('ame_offline_accounts'); } catch (e) { accounts = fromLs('ame_offline_accounts'); }\n    if (!accounts.length) accounts = [{ id: 0, name: 'ক্যাশ (ফোন)' }];\n  }\n  function fillAccounts() {\n    var sel = $('deskPayMethod');\n    if (!sel) return;\n    sel.innerHTML = accounts.map(function (a) {\n      return '<option value=\"' + a.id + '\">' + esc(a.name || a.account_name || '') + '</option>';\n    }).join('') || '<option value=\"\">অ্যাকাউন্ট নেই</option>';\n  }\n  function lineTotal(item) {\n    var disc = num(item.disc_pct);\n    var qty = num(item.qty);\n    var rate = num(item.current_price);\n    return qty * rate * (1 - disc / 100);\n  }\n  function subtotal() {\n    return cart.reduce(function (s, i) { return s + lineTotal(i); }, 0);\n  }\n  function discountTaka() { return Math.max(0, num($('deskDiscountTaka') && $('deskDiscountTaka').value)); }\n  function rounding() { return num($('rounding') && $('rounding').value); }\n  function grand() { return Math.max(0, subtotal() - discountTaka() + rounding()); }\n  function paid() { return Math.max(0, num($('deskPaid') && $('deskPaid').value)); }\n\n  function calc() {\n    var g = grand();\n    var p = paid();\n    var due = Math.max(0, g - p);\n    var change = Math.max(0, p - g);\n    if ($('deskSubtotal')) $('deskSubtotal').textContent = money(subtotal());\n    if ($('deskAfter')) $('deskAfter').textContent = money(Math.max(0, subtotal() - discountTaka()));\n    if ($('deskGrand')) $('deskGrand').textContent = '৳ ' + money(g);\n    if ($('deskDue')) $('deskDue').textContent = money(due);\n    if ($('deskChange')) $('deskChange').textContent = money(change);\n    var after = customerDue + due - change;\n    if ($('deskRunAmount')) $('deskRunAmount').textContent = money(Math.abs(after));\n    if ($('deskRunTag')) {\n      $('deskRunTag').textContent = after > 0.009 ? 'বাকি' : (after < -0.009 ? 'জমা' : 'সমান');\n    }\n  }\n\n  function drawCart() {\n    var body = $('cart-body');\n    if (!body) return;\n    var rows = cart.map(function (item, idx) {\n      return '<tr>' +\n        '<td>' + (idx + 1) + '</td>' +\n        '<td><input type=\"checkbox\"></td>' +\n        '<td>' + esc(item.sku) + '</td>' +\n        '<td style=\"text-align:left\">' + esc(item.name) + '</td>' +\n        '<td><input type=\"number\" min=\"0.01\" step=\"0.01\" data-qty=\"' + idx + '\" value=\"' + item.qty + '\"></td>' +\n        '<td><input type=\"number\" min=\"0\" step=\"0.01\" data-rate=\"' + idx + '\" value=\"' + item.current_price + '\"></td>' +\n        '<td><input type=\"number\" min=\"0\" max=\"100\" step=\"0.01\" data-disc=\"' + idx + '\" value=\"' + (item.disc_pct || 0) + '\"></td>' +\n        '<td>' + money(lineTotal(item)) + '</td>' +\n        '<td><button type=\"button\" class=\"ame-desk-remove\" data-del=\"' + idx + '\">×</button></td>' +\n        '</tr>';\n    });\n    var empty = Math.max(0, 2 - cart.length);\n    for (var i = 0; i < empty; i++) {\n      rows.push('<tr class=\"ame-pos-blank-row\"><td>' + (cart.length + i + 1) + '</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>');\n    }\n    if (!cart.length && empty === 0) {\n      rows.push('<tr class=\"ame-pos-empty-row\"><td colspan=\"9\">কার্ট খালি। যন্ত্রাংশ সার্চ করে যোগ করুন।</td></tr>');\n    }\n    body.innerHTML = rows.join('');\n    calc();\n  }\n\n  function addProduct(p) {\n    var rate = priceOf(p);\n    var ex = cart.filter(function (i) { return Number(i.id) === Number(p.id) && !i.is_custom; })[0];\n    if (ex) ex.qty = num(ex.qty) + 1;\n    else {\n      cart.push({\n        id: p.id,\n        sku: p.sku || '',\n        name: p.name,\n        sale_price: num(p.sale_price),\n        wholesale_price: num(p.wholesale_price),\n        dealer_price: num(p.dealer_price),\n        stock: p.stock,\n        current_price: rate,\n        qty: 1,\n        disc_pct: 0,\n        is_custom: false,\n        unit: p.unit || ''\n      });\n    }\n    var q = $('p-search');\n    if (q) q.value = '';\n    closeHits();\n    drawCart();\n  }\n\n  function closeHits() {\n    var box = $('search-res');\n    if (!box) return;\n    box.innerHTML = '';\n    box.classList.remove('is-open');\n  }\n  function paintHits(list) {\n    var box = $('search-res');\n    if (!box) return;\n    if (!list || !list.length) {\n      closeHits();\n      return;\n    }\n    box.innerHTML = list.slice(0, 24).map(function (p) {\n      return '<button type=\"button\" class=\"res-item\" data-id=\"' + p.id + '\"><b>' + esc(p.name) +\n        '</b><small>' + esc(p.sku || '') + ' · স্টক ' + (p.stock || 0) + ' · ৳ ' + money(priceOf(p)) + '</small></button>';\n    }).join('');\n    box.classList.add('is-open');\n  }\n\n  function paintCustomers(list) {\n    var box = $('posCustomerSearchList');\n    if (!box) return;\n    if (!list || !list.length) {\n      box.hidden = true;\n      box.innerHTML = '';\n      return;\n    }\n    box.hidden = false;\n    box.innerHTML = list.slice(0, 15).map(function (c) {\n      return '<li><button type=\"button\" data-cid=\"' + c.id + '\" data-name=\"' + esc(c.name) + '\" data-due=\"' + num(c.balance) + '\">' +\n        esc(c.name) + ' <small>' + esc(c.phone || '') + ' · বকেয়া ৳ ' + money(c.balance) + '</small></button></li>';\n    }).join('');\n  }\n\n  function tickClock() {\n    var el = $('ameDeskClock');\n    var dateEl = $('ameDeskDate');\n    var now = new Date();\n    if (el) {\n      el.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });\n    }\n    if (dateEl) dateEl.textContent = todayLabel();\n  }\n\n  function customerType() {\n    var checked = document.querySelector('input[name=\"cus_type_toolbar\"]:checked');\n    return (checked && checked.value) || 'Retail';\n  }\n\n  function completeSale() {\n    if (!cart.length) { alert('কার্ট খালি'); return; }\n    var accountId = num($('deskPayMethod') && $('deskPayMethod').value);\n    var g = grand();\n    var p = paid();\n    var type = customerType();\n    var cid = type === 'Retail' ? 0 : customerId;\n    var payload = {\n      action: 'complete',\n      cart: cart,\n      customer_id: cid || null,\n      customer_type: type,\n      subtotal: subtotal(),\n      discount: discountTaka(),\n      vat_percent: 0,\n      rounding: rounding(),\n      service_amount: 0,\n      services: [],\n      payments: [{ account_id: accountId, amount: p, reference_number: '' }],\n      exchange: [],\n      adjust_due: false,\n      sms: !!( $('send-sms') && $('send-sms').checked ),\n      sale_date: ($('ameSaleDate') && $('ameSaleDate').value) || todayInput(),\n      next_pay_date: ($('ameNextPayDate') && $('ameNextPayDate').value) || '',\n      next_pay_amount: num($('ameNextPayAmount') && $('ameNextPayAmount').value),\n      csrf_token: global.AME_CSRF_TOKEN || '',\n      offline_client_ref: (global.AmeOfflineQueue && AmeOfflineQueue.makeRef) ? AmeOfflineQueue.makeRef() : ('OFF-' + Date.now())\n    };\n    var sendFn = global.AmeOfflineQueue && AmeOfflineQueue.sendSale\n      ? AmeOfflineQueue.sendSale(payload)\n      : Promise.resolve({ queued: true, ref: payload.offline_client_ref });\n    var send = global.ameWaitSend ? global.ameWaitSend(sendFn) : sendFn;\n    Promise.resolve(send).then(function (res) {\n      var box = $('okBox');\n      if (box) box.style.display = 'block';\n      if (res && res.ok) {\n        if (box) box.textContent = 'বিক্রয় জমা হয়েছে।';\n        if (res.sale_id) location.href = '/modules/sales/invoice_digital.php?id=' + res.sale_id;\n        return;\n      }\n      if (res && res.queued) {\n        if (box) box.textContent = 'ফোনে সংরক্ষিত। নেট ফিরলে জমা হবে। রেফ: ' + res.ref;\n        cart = [];\n        drawCart();\n        if ($('deskPaid')) $('deskPaid').value = '0';\n        if ($('deskDiscountTaka')) $('deskDiscountTaka').value = '0';\n        calc();\n        return;\n      }\n      if (box) box.textContent = (res && res.error) || 'বিক্রয় যায়নি';\n    });\n  }\n\n  function bind() {\n    loadLocal();\n    fillAccounts();\n    if ($('ameSaleDate')) $('ameSaleDate').value = todayInput();\n    tickClock();\n    setInterval(tickClock, 1000);\n    if ($('warn')) $('warn').style.display = products.length ? 'none' : 'block';\n    drawCart();\n\n    if (global.navigator.onLine && global.AmeOfflineCatalog && AmeOfflineCatalog.refresh) {\n      AmeOfflineCatalog.refresh().then(function () {\n        loadLocal();\n        fillAccounts();\n        if ($('warn')) $('warn').style.display = products.length ? 'none' : 'block';\n      }).catch(function () {});\n    }\n\n    document.querySelectorAll('input[name=\"price_mode\"]').forEach(function (el) {\n      el.addEventListener('change', function () {\n        document.querySelectorAll('.ame-pos-mode').forEach(function (lab) { lab.classList.remove('is-on'); });\n        if (this.parentNode) this.parentNode.classList.add('is-on');\n        priceMode = this.value;\n        cart.forEach(function (item) {\n          if (item.is_custom) return;\n          var p = products.filter(function (x) { return Number(x.id) === Number(item.id); })[0];\n          if (p) item.current_price = priceOf(p);\n        });\n        drawCart();\n      });\n    });\n\n    $('p-search') && $('p-search').addEventListener('input', function () {\n      var q = this.value.trim();\n      if (!q) { closeHits(); return; }\n      var hits = [];\n      if (q.length >= 2 || /^\\d+$/.test(q)) {\n        hits = (global.AmeOfflineCatalog && AmeOfflineCatalog.searchProducts)\n          ? AmeOfflineCatalog.searchProducts(q)\n          : products.filter(function (p) {\n              return ((p.name || '') + ' ' + (p.sku || '') + ' ' + (p.barcode || '') + ' ' + p.id).toLowerCase().indexOf(q.toLowerCase()) !== -1;\n            });\n      }\n      paintHits(hits);\n    });\n    $('search-res') && $('search-res').addEventListener('click', function (e) {\n      var row = e.target.closest('[data-id]');\n      if (!row) return;\n      var p = products.filter(function (x) { return Number(x.id) === Number(row.getAttribute('data-id')); })[0];\n      if (p) addProduct(p);\n    });\n\n    $('cart-body') && $('cart-body').addEventListener('input', function (e) {\n      var qty = e.target.getAttribute('data-qty');\n      var rate = e.target.getAttribute('data-rate');\n      var disc = e.target.getAttribute('data-disc');\n      if (qty != null) cart[Number(qty)].qty = Math.max(0.01, num(e.target.value));\n      if (rate != null) cart[Number(rate)].current_price = Math.max(0, num(e.target.value));\n      if (disc != null) cart[Number(disc)].disc_pct = Math.max(0, Math.min(100, num(e.target.value)));\n      drawCart();\n    });\n    $('cart-body') && $('cart-body').addEventListener('click', function (e) {\n      var del = e.target.getAttribute('data-del');\n      if (del == null) return;\n      cart.splice(Number(del), 1);\n      drawCart();\n    });\n\n    $('posCustomerInfoField') && $('posCustomerInfoField').addEventListener('input', function () {\n      customerId = 0;\n      customerName = '';\n      var q = this.value.trim().toLowerCase();\n      if (!q) { paintCustomers([]); return; }\n      paintCustomers(customers.filter(function (c) {\n        return (c.name || '').toLowerCase().indexOf(q) !== -1\n          || (c.phone || '').indexOf(q) !== -1\n          || (c.code || '').toLowerCase().indexOf(q) !== -1;\n      }));\n    });\n    $('posCustomerSearchList') && $('posCustomerSearchList').addEventListener('click', function (e) {\n      var btn = e.target.closest('[data-cid]');\n      if (!btn) return;\n      customerId = Number(btn.getAttribute('data-cid'));\n      customerName = btn.getAttribute('data-name') || '';\n      customerDue = num(btn.getAttribute('data-due'));\n      if ($('posCustomerInfoField')) $('posCustomerInfoField').value = customerName;\n      paintCustomers([]);\n      var registered = document.querySelector('input[name=\"cus_type_toolbar\"][value=\"Registered\"]');\n      if (registered) registered.checked = true;\n      calc();\n    });\n\n    ['deskDiscountTaka', 'rounding', 'deskPaid'].forEach(function (id) {\n      $(id) && $(id).addEventListener('input', calc);\n    });\n    $('ameAddProductRow') && $('ameAddProductRow').addEventListener('click', function () {\n      $('p-search') && $('p-search').focus();\n    });\n    function addCustom() {\n      var name = global.prompt('পণ্যের নাম');\n      if (!name) return;\n      var price = num(global.prompt('দাম (৳)'));\n      cart.push({\n        id: 'c' + Date.now(), sku: '', name: name, sale_price: price, wholesale_price: price,\n        dealer_price: price, stock: 0, current_price: price, qty: 1, disc_pct: 0, is_custom: true, unit: ''\n      });\n      drawCart();\n    }\n    $('ameCustomAddHint') && $('ameCustomAddHint').addEventListener('click', addCustom);\n    $('openQuickCustomer') && $('openQuickCustomer').addEventListener('click', function () {\n      var name = global.prompt('ক্রেতার নাম');\n      if (!name) return;\n      customerId = 0;\n      customerName = name;\n      if ($('posCustomerInfoField')) $('posCustomerInfoField').value = name;\n    });\n    $('ameDeskMenuBtn') && $('ameDeskMenuBtn').addEventListener('click', function () {\n      location.href = '/offline.html';\n    });\n  }\n\n  global.submitFinalSale = completeSale;\n  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind);\n  else bind();\n})(window);\n\n</script>\n</body>\n</html>\n";
}

async function posPage(req, preloadP) {
  const cache = await caches.open(cacheName);
  const cached = (await fromAnyCache(req)) || (await matchAnyShell('/offline-sale.html'));
  const path = new URL(req.url).pathname || '';
  const isShell = path.indexOf('offline-sale.html') !== -1;
  if (isShell && cached) {
    fetchTimeout(req, 4000).then(function (fresh) { remember(cache, req, fresh); }).catch(function () {});
    return cached;
  }
  try {
    const fresh = (await takePreload(preloadP)) || await fetchTimeout(req, isShell ? 4000 : 2500, { cache: 'no-store' });
    if (fresh && fresh.ok) {
      await remember(cache, req, fresh);
      return fresh;
    }
  } catch (e) {}
  return cached || htmlResponse(saleHtml());
}
